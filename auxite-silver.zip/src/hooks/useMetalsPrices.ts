"use client";

import { useEffect, useRef, useState } from "react";
import { METALS, type MetalId } from "@/lib/metals";

export type PriceDirection = "up" | "down" | "same";

// UI'de opsiyonel kullanılan tip – şu an sadece type olarak import ediliyor
export interface MetalPrice {
  id: MetalId;
  symbol: string;
  name: string;
  pricePerGramAsk: number | null;
  pricePerGramBid: number | null;
  ts: number | null;
}

type PricesMap = Record<MetalId, number | null>; // USD/oz
type DirectionsMap = Record<MetalId, PriceDirection>;
type HistoryMap = Record<MetalId, number[]>;

interface ApiPriceItem {
  symbol: MetalId; // "AUXG" | "AUXS" | "AUXPT" | "AUXPD"
  price: number;   // USD/oz
  ts: number;
}

interface ApiResponse {
  ok: boolean;
  data: ApiPriceItem[];
  updatedAt?: string;
  error?: string;
}

interface UseMetalsPricesResult {
  prices: PricesMap;         // USD/oz
  directions: DirectionsMap;
  history: HistoryMap;
  loading: boolean;
  error: string | null;
  lastUpdated: Date | null;
}

function createInitialPrices(): PricesMap {
  return METALS.reduce((acc, m) => {
    acc[m.id] = null;
    return acc;
  }, {} as PricesMap);
}

function createInitialDirections(): DirectionsMap {
  return METALS.reduce((acc, m) => {
    acc[m.id] = "same";
    return acc;
  }, {} as DirectionsMap);
}

function createInitialHistory(): HistoryMap {
  return METALS.reduce((acc, m) => {
    acc[m.id] = [];
    return acc;
  }, {} as HistoryMap);
}

export function useMetalsPrices(): UseMetalsPricesResult {
  const [prices, setPrices] = useState<PricesMap>(() => createInitialPrices());
  const [directions, setDirections] = useState<DirectionsMap>(() =>
    createInitialDirections()
  );
  const [history, setHistory] = useState<HistoryMap>(() =>
    createInitialHistory()
  );
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const lastPricesRef = useRef<PricesMap | null>(null);

  async function fetchPrices() {
    try {
      setError(null);

      // Next.js API proxy → https://api.auxite.io/api/prices
      const res = await fetch("/api/prices", { cache: "no-store" });

      if (!res.ok) {
        throw new Error(`Fiyatlar alınamadı (HTTP ${res.status})`);
      }

      const json = (await res.json()) as ApiResponse;

      if (!json.ok || !Array.isArray(json.data)) {
        throw new Error(json.error ?? "Price API error");
      }

      const nextPrices: PricesMap = createInitialPrices();

      for (const item of json.data) {
        if (!METALS.find((m) => m.id === item.symbol)) continue;
        nextPrices[item.symbol] = item.price;
      }

      // yön hesapla
      setDirections((prev) => {
        const next = { ...prev };
        const last = lastPricesRef.current;

        METALS.forEach((m) => {
          const id = m.id;
          const newP = nextPrices[id];
          const oldP = last?.[id];

          if (newP == null || oldP == null) {
            next[id] = "same";
          } else if (newP > oldP) {
            next[id] = "up";
          } else if (newP < oldP) {
            next[id] = "down";
          } else {
            next[id] = "same";
          }
        });

        return next;
      });

      // history güncelle
      setHistory((prev) => {
        const next: HistoryMap = { ...prev };
        METALS.forEach((m) => {
          const id = m.id;
          const p = nextPrices[id];
          if (p != null) {
            const prevArr = next[id] ?? [];
            next[id] = [...prevArr, p].slice(-60);
          }
        });
        return next;
      });

      lastPricesRef.current = nextPrices;
      setPrices(nextPrices);
      setLastUpdated(
        json.updatedAt ? new Date(json.updatedAt) : new Date()
      );
      setLoading(false);
    } catch (e: any) {
      setError(e?.message ?? "Fiyatlar alınırken hata oluştu");
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchPrices();
    const interval = setInterval(fetchPrices, 10_000);
    return () => clearInterval(interval);
  }, []);

  return {
    prices,
    directions,
    history,
    loading,
    error,
    lastUpdated,
  };
}
