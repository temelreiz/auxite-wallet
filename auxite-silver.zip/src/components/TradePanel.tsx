"use client";

import { METALS, type MetalId } from "@/lib/metals";

type Side = "BUY" | "SELL";

type Props = {
  open: boolean;
  onClose: () => void;
  metalId: MetalId | null;
  side: Side;
  lang: "tr" | "en";
};

export default function TradePanel({
  open,
  onClose,
  metalId,
  side,
  lang,
}: Props) {
  if (!open || !metalId) return null;

  const metal = METALS.find((m) => m.id === metalId);
  if (!metal) return null;

  const isBuy = side === "BUY";

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="w-full max-w-md rounded-3xl border border-zinc-800 bg-zinc-950/95 p-5 shadow-xl">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <div className="text-xs uppercase tracking-[0.2em] text-zinc-500">
              {lang === "tr" ? "İşlem" : "Trade"}
            </div>
            <div className="text-sm font-semibold text-zinc-50">
              {isBuy
                ? lang === "tr"
                  ? "Alış"
                  : "Buy"
                : lang === "tr"
                ? "Satış"
                : "Sell"}{" "}
              · {metal.symbol}
            </div>
          </div>
          <button
            className="rounded-full px-2 py-1 text-xs text-zinc-400 hover:bg-zinc-800"
            onClick={onClose}
          >
            ✕
          </button>
        </div>

        {/* basit form placeholder */}
        <div className="space-y-3">
          <div className="text-xs text-zinc-400">
            {lang === "tr"
              ? "İşlem miktarını girin. Bu panelde daha sonra fiyat, slipaj, fee vb. ayrıntıları göstereceğiz."
              : "Enter trade amount. Later we’ll plug in price, slippage and fee details here."}
          </div>

          <div className="flex items-center gap-2 rounded-2xl border border-zinc-800 bg-zinc-900/50 px-3 py-2">
            <input
              type="number"
              min={0}
              placeholder={lang === "tr" ? "Miktar" : "Amount"}
              className="flex-1 bg-transparent text-sm text-zinc-50 outline-none placeholder:text-zinc-600"
            />
            <span className="text-xs text-zinc-500">AUX</span>
          </div>

          <button
            className={
              "mt-2 w-full rounded-full py-2 text-sm font-semibold text-white transition " +
              (isBuy
                ? "bg-emerald-500 hover:bg-emerald-400"
                : "bg-red-500 hover:bg-red-400")
            }
          >
            {isBuy
              ? lang === "tr"
                ? "Alışı Onayla"
                : "Confirm Buy"
              : lang === "tr"
              ? "Satışı Onayla"
              : "Confirm Sell"}
          </button>
        </div>
      </div>
    </div>
  );
}
