// src/components/TopNav.tsx
"use client";

type Props = {
  lang: "tr" | "en";
  theme: "dark" | "light";
  onLangChange: (lang: "tr" | "en") => void;
  onThemeChange: (theme: "dark" | "light") => void;
  activeTab: "markets" | "leasing";
  onTabChange: (tab: "markets" | "leasing") => void;
  onOpenWalletModal: () => void;
};

export default function TopNav({
  lang,
  theme,
  onLangChange,
  onThemeChange,
  activeTab,
  onTabChange,
  onOpenWalletModal,
}: Props) {
  const isDark = theme === "dark";

  const tabCls = (tab: "markets" | "leasing") =>
    "rounded-full px-3 py-1 text-xs font-medium transition " +
    (activeTab === tab
      ? "bg-emerald-500 text-white"
      : "text-zinc-400 hover:bg-zinc-800");

  return (
    <header className="flex items-center justify-between py-3">
      <div className="flex items-center gap-4">
        <div className="text-sm font-semibold text-zinc-50">Auxite Wallet</div>
        <nav className="hidden items-center gap-2 rounded-full bg-zinc-900/80 px-1 py-1 sm:flex">
          <button
            className={tabCls("markets")}
            onClick={() => onTabChange("markets")}
          >
            {lang === "tr" ? "Piyasalar" : "Markets"}
          </button>
          <button
            className={tabCls("leasing")}
            onClick={() => onTabChange("leasing")}
          >
            Leasing
          </button>
        </nav>
      </div>

      <div className="flex items-center gap-3">
        {/* Tema toggle */}
        <button
          onClick={() => onThemeChange(isDark ? "light" : "dark")}
          className="rounded-full bg-zinc-900/80 px-2 py-1 text-[11px] text-zinc-400 hover:bg-zinc-800"
        >
          {isDark ? "☀︎ Light" : "🌙 Dark"}
        </button>

        {/* Dil toggle */}
        <button
          onClick={() => onLangChange(lang === "tr" ? "en" : "tr")}
          className="rounded-full bg-zinc-900/80 px-2 py-1 text-[11px] text-zinc-400 hover:bg-zinc-800"
        >
          {lang === "tr" ? "EN" : "TR"}
        </button>

        {/* Wallet connect */}
        <button
          onClick={onOpenWalletModal}
          className="rounded-full bg-emerald-500 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-400"
        >
          {lang === "tr" ? "Cüzdan Bağla" : "Connect Wallet"}
        </button>
      </div>
    </header>
  );
}
