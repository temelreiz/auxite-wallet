"use client";

import { useState } from "react";

type UiLang = "tr" | "en";
type UiTheme = "dark" | "light";

type Props = {
  lang: UiLang;
  theme: UiTheme;
};

type TvSymbolConfig = {
  id: string;
  label: string;
  tvSymbol: string;
};

const METAL_TV_SYMBOLS: TvSymbolConfig[] = [
  { id: "AUXG", label: "AUXG · Gold", tvSymbol: "OANDA:XAUUSD" },
  { id: "AUXS", label: "AUXS · Silver", tvSymbol: "OANDA:XAGUSD" },
  { id: "AUXPT", label: "AUXPT · Platinum", tvSymbol: "FX_IDC:XPTUSD" },
  { id: "AUXPD", label: "AUXPD · Palladium", tvSymbol: "FX_IDC:XPDUSD" },
];

export default function MarketOverview({ lang, theme }: Props) {
  const isDark = theme === "dark";
  const [activeId, setActiveId] = useState<string>("AUXG");

  const activeCfg =
    METAL_TV_SYMBOLS.find((m) => m.id === activeId) ?? METAL_TV_SYMBOLS[0];

  const params = new URLSearchParams({
    symbol: activeCfg.tvSymbol,
    interval: "60", // 1 saatlik mumlar
    theme: isDark ? "dark" : "light",
    style: "1",
    locale: lang === "tr" ? "tr" : "en",
    hide_top_toolbar: "1",
    hide_legend: "1",
    save_image: "0",
    autosize: "1",
  });

  const src = `https://s.tradingview.com/widgetembed/?${params.toString()}`;

  return (
    <div
      className={
        (isDark
          ? "rounded-3xl border border-slate-800 bg-slate-900/80"
          : "rounded-3xl border border-slate-200 bg-white") +
        " px-5 py-4 shadow-sm"
      }
    >
      <div className="mb-3 flex items-center justify-between text-xs text-slate-400">
        <span>{lang === "tr" ? "Piyasa Özeti" : "Market Overview"}</span>
        <span className="text-[10px] uppercase tracking-[0.18em]">
          Charts / TV integration
        </span>
      </div>

      {/* Metal sekmeleri */}
      <div className="mb-3 flex flex-wrap gap-2 text-[11px]">
        {METAL_TV_SYMBOLS.map((m) => {
          const active = m.id === activeId;
          return (
            <button
              key={m.id}
              type="button"
              onClick={() => setActiveId(m.id)}
              className={
                "rounded-full border px-3 py-1 transition " +
                (active
                  ? isDark
                    ? "border-emerald-400 bg-emerald-500/10 text-emerald-300"
                    : "border-emerald-500 bg-emerald-50 text-emerald-700"
                  : isDark
                  ? "border-slate-700 bg-slate-900 text-slate-300 hover:border-slate-500"
                  : "border-slate-200 bg-slate-50 text-slate-600 hover:border-slate-400")
              }
            >
              {m.label}
            </button>
          );
        })}
      </div>

      {/* TradingView iframe */}
      <div className="h-64 w-full overflow-hidden rounded-2xl border border-slate-700/70">
        <iframe
        key={src}
        src={src}
        className="h-full w-full"
        frameBorder="0"
        allowFullScreen
        scrolling="no"
        />

      </div>

      <div className="mt-1 text-[10px] text-slate-500">
        {lang === "tr"
          ? "Veriler TradingView üzerinden, XAUUSD / XAGUSD / XPTUSD / XPDUSD spot fiyatlarına göre gösterilir."
          : "Data via TradingView, showing XAUUSD / XAGUSD / XPTUSD / XPDUSD spot prices."}
      </div>
    </div>
  );
}
