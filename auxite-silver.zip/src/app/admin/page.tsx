"use client";

import { useEffect, useState } from "react";
import { ethers } from "ethers";

type MetalKey = "AUXG" | "AUXS" | "AUXPT" | "AUXPD";

const METAL_LABELS: Record<MetalKey, string> = {
  AUXG: "Auxite Gold (AUXG)",
  AUXS: "Auxite Silver (AUXS)",
  AUXPT: "Auxite Platinum (AUXPT)",
  AUXPD: "Auxite Palladium (AUXPD)",
};

// ENV’den adresleri çek
const METAL_ADDRESSES: Record<MetalKey, string | undefined> = {
  AUXG: process.env.NEXT_PUBLIC_AUXG_ADDRESS,
  AUXS: process.env.NEXT_PUBLIC_AUXS_ADDRESS,
  AUXPT: process.env.NEXT_PUBLIC_AUXPT_ADDRESS,
  AUXPD: process.env.NEXT_PUBLIC_AUXPD_ADDRESS,
};

// V3 tokenler için minimal ABI
const V3_ABI = [
  {
    inputs: [],
    name: "askAddPerKgE6",
    outputs: [{ internalType: "uint256", name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "bidSubPerKgE6",
    outputs: [{ internalType: "uint256", name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      { internalType: "uint256", name: "newAskAddPerKgE6", type: "uint256" },
      { internalType: "uint256", name: "newBidSubPerKgE6", type: "uint256" },
    ],
    name: "setSpreadPerKgE6",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
] as const;

export default function AdminPage() {
  const [selectedMetal, setSelectedMetal] = useState<MetalKey>("AUXG");
  const [connectedAddress, setConnectedAddress] = useState<string | null>(null);
  const [network, setNetwork] = useState<string | null>(null);

  const [currentAskUsd, setCurrentAskUsd] = useState<string>("-");
  const [currentBidUsd, setCurrentBidUsd] = useState<string>("-");

  const [askInput, setAskInput] = useState<string>("");
  const [bidInput, setBidInput] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [txHash, setTxHash] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const address = METAL_ADDRESSES[selectedMetal];

  // Metamask bağlantısını oku
  useEffect(() => {
    if (typeof window === "undefined") return;
    const eth = (window as any).ethereum;
    if (!eth) return;

    (async () => {
      try {
        const provider = new ethers.BrowserProvider(eth);
        const net = await provider.getNetwork();
        setNetwork(net.chainId ? net.chainId.toString() : null);

        const accounts: string[] = await eth.request({
          method: "eth_accounts",
        });
        if (accounts && accounts.length > 0) {
          setConnectedAddress(ethers.getAddress(accounts[0]));
        }
      } catch (e) {
        console.error(e);
      }
    })();
  }, []);

  // Metal değişince mevcut spread değerlerini oku
  useEffect(() => {
    if (!address) {
      setCurrentAskUsd("-");
      setCurrentBidUsd("-");
      return;
    }
    if (typeof window === "undefined") return;
    const eth = (window as any).ethereum;
    if (!eth) return;

    (async () => {
      try {
        setError(null);
        const provider = new ethers.BrowserProvider(eth);
        const contract = new ethers.Contract(address, V3_ABI, provider);

        const askE6: bigint = await contract.askAddPerKgE6();
        const bidE6: bigint = await contract.bidSubPerKgE6();

        const askUsd = Number(askE6) / 1_000_000;
        const bidUsd = Number(bidE6) / 1_000_000;

        setCurrentAskUsd(askUsd.toFixed(2));
        setCurrentBidUsd(bidUsd.toFixed(2));

        // inputlar boşsa mevcut değerleri default olarak göster
        if (!askInput) setAskInput(askUsd.toString());
        if (!bidInput) setBidInput(bidUsd.toString());
      } catch (e: any) {
        console.error(e);
        setError("Mevcut spread okunamadı. ABI / adres / ağ kontrol ediniz.");
        setCurrentAskUsd("-");
        setCurrentBidUsd("-");
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedMetal, address]);

  async function connectWallet() {
    if (typeof window === "undefined") return;
    const eth = (window as any).ethereum;
    if (!eth) {
      setError("Ethereum wallet (Metamask / Rabby) bulunamadı.");
      return;
    }
    try {
      const accounts: string[] = await eth.request({
        method: "eth_requestAccounts",
      });
      if (accounts && accounts.length > 0) {
        setConnectedAddress(ethers.getAddress(accounts[0]));
        const provider = new ethers.BrowserProvider(eth);
        const net = await provider.getNetwork();
        setNetwork(net.chainId ? net.chainId.toString() : null);
      }
    } catch (e: any) {
      console.error(e);
      setError("Cüzdan bağlantısı reddedildi veya başarısız.");
    }
  }

  async function handleUpdate() {
    setTxHash(null);
    setError(null);

    if (!address) {
      setError("Seçili metal için kontrat adresi bulunamadı (ENV).");
      return;
    }
    if (typeof window === "undefined") return;
    const eth = (window as any).ethereum;
    if (!eth) {
      setError("Ethereum provider bulunamadı (Metamask / Rabby).");
      return;
    }
    if (!connectedAddress) {
      setError("Lütfen önce admin cüzdanı bağlayın.");
      return;
    }

    let askUsd = askInput ? Number(askInput) : NaN;
    let bidUsd = bidInput ? Number(bidInput) : NaN;
    if (!Number.isFinite(askUsd) || askUsd < 0) {
      setError("Geçerli bir ASK (USD/kg) girin.");
      return;
    }
    if (!Number.isFinite(bidUsd) || bidUsd < 0) {
      setError("Geçerli bir BID (USD/kg) girin.");
      return;
    }

    try {
      setLoading(true);
      const provider = new ethers.BrowserProvider(eth);
      const signer = await provider.getSigner();
      const contract = new ethers.Contract(address, V3_ABI, signer);

      const askE6 = BigInt(Math.round(askUsd * 1_000_000));
      const bidE6 = BigInt(Math.round(bidUsd * 1_000_000));

      const tx = await contract.setSpreadPerKgE6(askE6, bidE6);
      setTxHash(tx.hash);
      await tx.wait();

      // Başarılıysa current değerleri güncelle
      setCurrentAskUsd(askUsd.toFixed(2));
      setCurrentBidUsd(bidUsd.toFixed(2));
    } catch (e: any) {
      console.error(e);
      setError(e?.reason || e?.message || "İşlem sırasında hata oluştu.");
    } finally {
      setLoading(false);
    }
  }

  const bgCls = "min-h-screen bg-slate-950 text-slate-50";
  const cardCls =
    "rounded-3xl border border-slate-800 bg-slate-900/80 px-6 py-5 shadow-lg max-w-3xl mx-auto mt-10";

  return (
    <main className={bgCls}>
      <div className="mx-auto max-w-4xl px-4 pt-6">
        <header className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-xl font-semibold text-emerald-400">
              Auxite Admin · Spread Panel
            </h1>
            <p className="mt-1 text-xs text-slate-400">
              AUXG / AUXS / AUXPT / AUXPD için USD/kg spread ayarları. Sadece
              admin cüzdanlar kullanmalıdır.
            </p>
          </div>
          <div className="flex flex-col items-start gap-1 text-xs sm:items-end">
            <button
              type="button"
              onClick={connectWallet}
              className="rounded-full border border-emerald-500 px-3 py-1 text-[11px] font-semibold text-emerald-300 hover:bg-emerald-500/10"
            >
              {connectedAddress
                ? `Bağlandı: ${connectedAddress.slice(
                    0,
                    6
                  )}...${connectedAddress.slice(-4)}`
                : "Cüzdanı Bağla"}
            </button>
            <span className="text-slate-500">
              Ağ: {network ? network : "bilinmiyor"}
            </span>
          </div>
        </header>

        <section className={cardCls}>
          {/* Metal seçimi */}
          <div className="mb-4">
            <label className="mb-1 block text-xs font-semibold text-slate-300">
              Metal Seç
            </label>
            <div className="flex flex-wrap gap-2">
              {(Object.keys(METAL_LABELS) as MetalKey[]).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => {
                    setSelectedMetal(m);
                    setAskInput("");
                    setBidInput("");
                    setTxHash(null);
                    setError(null);
                  }}
                  className={
                    "rounded-full border px-3 py-1 text-[11px] " +
                    (selectedMetal === m
                      ? "border-emerald-500 bg-emerald-500/10 text-emerald-300"
                      : "border-slate-700 bg-slate-900 text-slate-300 hover:border-slate-500")
                  }
                >
                  {METAL_LABELS[m]}
                </button>
              ))}
            </div>
            <p className="mt-1 text-[11px] text-slate-500">
              Kontrat adresi:{" "}
              <span className="font-mono text-[10px] text-slate-300">
                {address || "(ENV tanımlı değil)"}
              </span>
            </p>
          </div>

          {/* Mevcut değerler */}
          <div className="mb-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-3 text-xs">
              <div className="text-slate-400">Mevcut ASK spread</div>
              <div className="mt-1 text-lg font-semibold text-emerald-400">
                {currentAskUsd} <span className="text-xs">USD/kg</span>
              </div>
            </div>
            <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-3 text-xs">
              <div className="text-slate-400">Mevcut BID spread</div>
              <div className="mt-1 text-lg font-semibold text-rose-400">
                {currentBidUsd} <span className="text-xs">USD/kg</span>
              </div>
            </div>
          </div>

          {/* Yeni değerler */}
          <div className="mb-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs text-slate-300">
                Yeni ASK (USD/kg)
              </label>
              <input
                type="number"
                step="0.01"
                value={askInput}
                onChange={(e) => setAskInput(e.target.value)}
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-slate-100 outline-none focus:border-emerald-500"
                placeholder="Örn: 10"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs text-slate-300">
                Yeni BID (USD/kg)
              </label>
              <input
                type="number"
                step="0.01"
                value={bidInput}
                onChange={(e) => setBidInput(e.target.value)}
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-slate-100 outline-none focus:border-rose-500"
                placeholder="Örn: 100"
              />
            </div>
          </div>

          {/* Hata / Tx bilgisi */}
          {error && (
            <p className="mb-3 rounded-xl border border-red-500/40 bg-red-500/10 px-3 py-2 text-[11px] text-red-200">
              {error}
            </p>
          )}
          {txHash && (
            <p className="mb-3 rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-3 py-2 text-[11px] text-emerald-200">
              Güncelleme işlemi gönderildi. Tx:{" "}
              <span className="font-mono break-all">{txHash}</span>
            </p>
          )}

          {/* Güncelle butonu */}
          <div className="flex justify-end">
            <button
              type="button"
              onClick={handleUpdate}
              disabled={loading}
              className="rounded-full bg-emerald-500 px-5 py-2 text-xs font-semibold text-white shadow hover:bg-emerald-400 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {loading ? "Güncelleniyor…" : "Spread Güncelle"}
            </button>
          </div>
        </section>
      </div>
    </main>
  );
}

