"use client";

import Link from "next/link";
import {
  AUXITE_LEASING_OFFERS,
  auxiteLeasingOfferAbi,
} from "@/lib/leasing";
import { useAccount, usePublicClient } from "wagmi";
import { formatUnits } from "viem";
import { useEffect, useState } from "react";

type TotalsBySymbol = Record<"AUXG" | "AUXS" | "AUXPT" | "AUXPD", bigint>;

const EMPTY_TOTALS: TotalsBySymbol = {
  AUXG: 0n,
  AUXS: 0n,
  AUXPT: 0n,
  AUXPD: 0n,
};

export default function LeasingPage() {
  return (
    <main className="px-5 py-6 space-y-6 max-w-5xl mx-auto">
      <header className="space-y-2">
        <h1 className="text-2xl font-semibold">Auxite Leasing</h1>
        <p className="text-sm text-muted-foreground">
          Değerli metallere dayalı leasing programları. Buradaki ürünler yatırım
          tavsiyesi değildir; Auxite Wallet sadece yetkili kurum tarafından
          sunulan ürünleri görüntülemek ve akıllı kontratlarla etkileşim kurmak
          için kullanılan bir arayüzdür.
        </p>
      </header>

      {/* 🔹 Toplam portföy widget'ı */}
      <LeasingPortfolioWidget />

      {/* 🔹 Ürün listesi */}
      <section className="grid gap-3">
        {AUXITE_LEASING_OFFERS.map((o) => (
          <Link
            key={o.id}
            href={`/leasing/${o.id}`}
            className="border border-white/10 rounded-xl p-4 flex flex-col gap-2 hover:bg-white/5 transition"
          >
            <div className="flex justify-between items-center gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-medium">
                    {o.symbol} – {o.lockDays} gün leasing
                  </span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Yetkili metal kuruluşu: {o.dealerName}
                </p>
              </div>
              <div className="text-right text-xs text-muted-foreground">
                <div>
                  Minimum {o.minAmount} {o.symbol}
                </div>
              </div>
            </div>

            <p className="text-[11px] text-muted-foreground">
              Leasing getirileri, Auxite Kıymetli Madenler Tic. A.Ş.’nin ticari
              faaliyetlerinden elde edilen gelirlerin dağıtımına bağlıdır.
              Auxite Wallet, bu ticari gelirlerin tarafı veya garantörü
              değildir.
            </p>
          </Link>
        ))}
      </section>

      {/* Uyum / risk disclaimer */}
      <section className="border border-yellow-500/30 bg-yellow-500/5 text-yellow-100 rounded-xl p-4 space-y-2 text-[11px]">
        <p className="font-medium">Uyumluluk ve risk bildirimi</p>
        <ul className="list-disc list-inside space-y-1">
          <li>
            Auxite Wallet, sadece akıllı kontratlar ile etkileşime geçen bir
            arayüzdür; leasing ürünlerinin ihraççısı, satıcısı veya garantörü
            değildir.
          </li>
          <li>
            Leasing programları, Auxite Kıymetli Madenler Tic. A.Ş.’nin ticari
            faaliyetlerine dayalıdır ve getiriler önceden garanti edilmez.
          </li>
          <li>
            Kullanıcılar, leasinge katılmadan önce kendi risk değerlendirmesini
            yapmalı ve gerekirse bağımsız bir danışmandan görüş almalıdır.
          </li>
          <li>
            Bu ekran yatırım tavsiyesi niteliği taşımaz; sadece bilgi amaçlıdır.
          </li>
        </ul>
      </section>
    </main>
  );
}

/**
 * Kullanıcının tüm leasing ürünlerindeki toplam kilitli miktarını gösteren widget.
 * Her offer için numPositions + getPosition ile aktif (closed=false) pozisyonları toplar.
 */
function LeasingPortfolioWidget() {
  const { address: userAddress } = useAccount();
  const client = usePublicClient();
  const [totals, setTotals] = useState<TotalsBySymbol>(EMPTY_TOTALS);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    // Eğer client veya adres yoksa, totals'ı sıfırla
    if (!client || !userAddress) {
      setTotals(EMPTY_TOTALS);
      return;
    }

    // TypeScript narrowing için lokal değişkenlere alıyoruz
    const c = client;
    const addr = userAddress;

    let cancelled = false;

    async function load() {
      try {
        setIsLoading(true);
        let acc: TotalsBySymbol = { ...EMPTY_TOTALS };

        for (const offer of AUXITE_LEASING_OFFERS) {
          // Her offer için kullanıcı pozisyon sayısı
          const num = await c.readContract({
            abi: auxiteLeasingOfferAbi,
            address: offer.address,
            functionName: "numPositions",
            args: [addr],
          });

          const count = Number((num as bigint) ?? 0n);
          if (count === 0) continue;

          for (let i = 0; i < count; i++) {
            const pos = await c.readContract({
              abi: auxiteLeasingOfferAbi,
              address: offer.address,
              functionName: "getPosition",
              args: [addr, BigInt(i)],
            });

            const [amount, , , closed] = pos as unknown as [
              bigint,
              bigint,
              bigint,
              boolean,
              boolean
            ];

            if (!closed) {
              acc[offer.symbol] = (acc[offer.symbol] ?? 0n) + amount;
            }
          }
        }

        if (!cancelled) {
          setTotals(acc);
        }
      } catch (e) {
        console.error("Leasing portfolio load error", e);
        if (!cancelled) {
          setTotals(EMPTY_TOTALS);
        }
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    }

    load();

    return () => {
      cancelled = true;
    };
  }, [client, userAddress]);

  const hasAny =
    totals.AUXG || totals.AUXS || totals.AUXPT || totals.AUXPD;

  if (!userAddress) {
    return (
      <section className="border border-white/10 rounded-xl p-4 text-sm text-muted-foreground">
        Leasing portföyünü görmek için cüzdanını bağlamalısın.
      </section>
    );
  }

  if (!hasAny && !isLoading) {
    return (
      <section className="border border-white/10 rounded-xl p-4 text-sm text-muted-foreground">
        Bu cüzdan ile aktif leasing pozisyonun bulunmuyor.
      </section>
    );
  }

  return (
    <section className="border border-white/10 rounded-xl p-4 space-y-2 text-sm">
      <div className="flex justify-between items-center">
        <span className="font-medium">Leasing Portföyün</span>
        <span className="text-xs text-muted-foreground">
          {isLoading ? "Hesaplanıyor..." : "Güncel kilitli bakiyeler"}
        </span>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-2 text-xs">
        {(["AUXG", "AUXS", "AUXPT", "AUXPD"] as const).map((sym) => {
          const raw = totals[sym];
          if (raw === 0n && !isLoading) {
            return (
              <div
                key={sym}
                className="border border-white/5 rounded-lg px-3 py-2 text-muted-foreground"
              >
                <div className="font-medium">{sym}</div>
                <div className="text-[11px]">Aktif pozisyon yok</div>
              </div>
            );
          }

          return (
            <div
              key={sym}
              className="border border-white/10 rounded-lg px-3 py-2"
            >
              <div className="font-medium">{sym}</div>
              <div className="text-[11px] text-muted-foreground">
                {isLoading
                  ? "Yükleniyor..."
                  : `${Number(
                      formatUnits(raw, 18)
                    ).toFixed(4)} ${sym} kilitli`}
              </div>
            </div>
          );
        })}
      </div>

      <p className="text-[11px] text-muted-foreground mt-1">
        Buradaki değerler yalnızca açık (kapalı olmayan) leasing pozisyonlarını
        içerir ve zincir üzerindeki akıllı kontratlardan okunur.
      </p>
    </section>
  );
}
