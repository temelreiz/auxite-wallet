"use client";

import type { ReactNode } from "react";
import { WagmiProvider } from "wagmi";
import { sepolia } from "wagmi/chains";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  createWeb3Modal,
  defaultWagmiConfig,
} from "@web3modal/wagmi/react";

const projectId =
  process.env.NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID || "demo";

// Tuple olması şart → TypeScript için gerekli
const chains = [sepolia] as const;

const metadata = {
  name: "Auxite Wallet",
  description: "RWA metal token wallet",
  url: "https://auxite.io",
  icons: ["https://assets.global/auxite.png"],
};

// Wagmi v1 config
const wagmiConfig = defaultWagmiConfig({
  chains,
  projectId,
  metadata,
});

// Web3Modal v4 — ❗ 'chains' parametresi yok
createWeb3Modal({
  wagmiConfig,
  projectId,
  themeMode: "dark",
  themeVariables: {
    "--w3m-accent": "#D4AF37",
  },
});

const queryClient = new QueryClient();

export default function Web3Provider({ children }: { children: ReactNode }) {
  return (
    <WagmiProvider config={wagmiConfig}>
      <QueryClientProvider client={queryClient}>
        {children}
      </QueryClientProvider>
    </WagmiProvider>
  );
}
