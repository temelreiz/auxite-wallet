"use client";

import { useEffect, useState } from "react";
import { ethers } from "ethers";
import AuxiteTokenAbi from "@/lib/abi/AuxiteToken.json";

type MetalKey = "AUXG" | "AUXS" | "AUXPT" | "AUXPD";

const METAL_LABELS: Record<MetalKey, string> = {
  AUXG: "Auxite Gold (AUXG)",
  AUXS: "Auxite Silver (AUXS)",
  AUXPT: "Auxite Platinum (AUXPT)",
  AUXPD: "Auxite Palladium (AUXPD)",
};

const METAL_ADDRESSES: Record<MetalKey, string | undefined> = {
  AUXG: process.env.NEXT_PUBLIC_AUXG_ADDRESS,
  AUXS: process.env.NEXT_PUBLIC_AUXS_ADDRESS,
  AUXPT: process.env.NEXT_PUBLIC_AUXPT_ADDRESS,
  AUXPD: process.env.NEXT_PUBLIC_AUXPD_ADDRESS,
};

const TOKEN_ABI = AuxiteTokenAbi as any;

export default function AdminPage() {
  const [selectedMetal, setSelectedMetal] = useState<MetalKey>("AUXG");
  const [connectedAddress, setConnectedAddress] = useState<string | null>(null);
  const [network, setNetwork] = useState<string | null>(null);

  // 1 oz kaç gram? (editlenebilir)
  const [ozFactor, setOzFactor] = useState<number>(31.1034768);

  // Spread (sadece USD/kg)
  const [currentAskSpreadUsdKg, setCurrentAskSpreadUsdKg] =
    useState<string>("-");
  const [currentBidSpreadUsdKg, setCurrentBidSpreadUsdKg] =
    useState<string>("-");

  // Nihai fiyatlar (ASK/BID, USD/g & USD/oz)
  const [gramAsk, setGramAsk] = useState<string>("-");
  const [gramBid, setGramBid] = useState<string>("-");
  const [ozAsk, setOzAsk] = useState<string>("-");
  const [ozBid, setOzBid] = useState<string>("-");

  // yeni spread inputları (USD/kg)
  const [askInput, setAskInput] = useState<string>("");
  const [bidInput, setBidInput] = useState<string>("");

  const [loading, setLoading] = useState(false);
  const [txHash, setTxHash] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const tokenAddress = METAL_ADDRESSES[selectedMetal];

  // ---------------------------------------------------------
  // Auto-connect wallet & network
  // ---------------------------------------------------------
  useEffect(() => {
    if (typeof window === "undefined") return;
    const eth = (window as any).ethereum;
    if (!eth) return;

    (async () => {
      try {
        const provider = new ethers.BrowserProvider(eth);
        const net = await provider.getNetwork();
        setNetwork(net.chainId ? net.chainId.toString() : null);

        const accounts: string[] = await eth.request({
          method: "eth_accounts",
        });
        if (accounts?.length > 0) {
          setConnectedAddress(ethers.getAddress(accounts[0]));
        }
      } catch (e) {
        console.error(e);
      }
    })();
  }, []);

  // ---------------------------------------------------------
  // Kontrattan spread + fiyatları oku
  // ---------------------------------------------------------
  useEffect(() => {
    if (!tokenAddress) {
      setCurrentAskSpreadUsdKg("-");
      setCurrentBidSpreadUsdKg("-");
      setGramAsk("-");
      setGramBid("-");
      setOzAsk("-");
      setOzBid("-");
      return;
    }

    if (typeof window === "undefined") return;
    const eth = (window as any).ethereum;
    if (!eth) return;

    (async () => {
      try {
        setError(null);

        const provider = new ethers.BrowserProvider(eth);
        const contract = new ethers.Contract(tokenAddress, TOKEN_ABI, provider);

        // 1) Spread parametreleri (USD/kg * 1e6)
        const askSpreadE6: bigint = await contract.askAddPerKgE6();
        const bidSpreadE6: bigint = await contract.bidSubPerKgE6();

        const askSpreadUsdKg = Number(askSpreadE6) / 1_000_000;
        const bidSpreadUsdKg = Number(bidSpreadE6) / 1_000_000;

        setCurrentAskSpreadUsdKg(askSpreadUsdKg.toFixed(2));
        setCurrentBidSpreadUsdKg(bidSpreadUsdKg.toFixed(2));

        // inputları ilk yüklemede doldur
        if (!askInput) setAskInput(askSpreadUsdKg.toString());
        if (!bidInput) setBidInput(bidSpreadUsdKg.toString());

        // 2) Gram fiyatları (USD/g * 1e6)
        const askGramE6: bigint = await contract.pricePerGramAskE6();
        const bidGramE6: bigint = await contract.pricePerGramBidE6();

        const usdGAsk = Number(askGramE6) / 1_000_000;
        const usdGBid = Number(bidGramE6) / 1_000_000;

        // 3) Oz fiyatları (ASK/BID)
        const factor = ozFactor || 31.1034768;
        const usdOzAsk = usdGAsk * factor;
        const usdOzBid = usdGBid * factor;

        setGramAsk(usdGAsk.toFixed(4));
        setGramBid(usdGBid.toFixed(4));
        setOzAsk(usdOzAsk.toFixed(2));
        setOzBid(usdOzBid.toFixed(2));
      } catch (e) {
        console.error(e);
        setError("Değerler okunamadı. ABI / adres / ağ kontrol edin.");
        setGramAsk("-");
        setGramBid("-");
        setOzAsk("-");
        setOzBid("-");
      }
    })();
    // ozFactor değişince fiyatları yeniden okuyup oz hesaplayalım
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedMetal, tokenAddress, ozFactor]);

  // ---------------------------------------------------------
  // Cüzdan bağla
  // ---------------------------------------------------------
  async function connectWallet() {
    if (typeof window === "undefined") return;
    const eth = (window as any).ethereum;

    if (!eth) {
      setError("Ethereum wallet bulunamadı.");
      return;
    }

    try {
      const accounts: string[] = await eth.request({
        method: "eth_requestAccounts",
      });

      if (accounts.length > 0) {
        setConnectedAddress(ethers.getAddress(accounts[0]));
      }

      const provider = new ethers.BrowserProvider(eth);
      const net = await provider.getNetwork();
      setNetwork(net.chainId ? net.chainId.toString() : null);
    } catch (e) {
      console.error(e);
      setError("Cüzdan bağlantısı yapılamadı.");
    }
  }

  // ---------------------------------------------------------
  // Spread güncelle
  // ---------------------------------------------------------
  async function handleUpdate() {
    setError(null);
    setTxHash(null);

    if (!tokenAddress) {
      setError("Kontrat adresi bulunamadı (ENV).");
      return;
    }

    if (!connectedAddress) {
      setError("Önce admin cüzdanı bağlayın.");
      return;
    }

    const askUsd = Number(askInput);
    const bidUsd = Number(bidInput);

    if (!Number.isFinite(askUsd) || askUsd < 0) {
      setError("Geçerli bir ASK spread (USD/kg) girin.");
      return;
    }
    if (!Number.isFinite(bidUsd) || bidUsd < 0) {
      setError("Geçerli bir BID spread (USD/kg) girin.");
      return;
    }

    try {
      setLoading(true);

      const provider = new ethers.BrowserProvider((window as any).ethereum);
      const signer = await provider.getSigner();
      const contract = new ethers.Contract(tokenAddress, TOKEN_ABI, signer);

      const askE6 = BigInt(Math.round(askUsd * 1_000_000));
      const bidE6 = BigInt(Math.round(bidUsd * 1_000_000));

      const tx = await contract.setSpreadPerKgE6(askE6, bidE6);
      setTxHash(tx.hash);

      await tx.wait();

      setCurrentAskSpreadUsdKg(askUsd.toFixed(2));
      setCurrentBidSpreadUsdKg(bidUsd.toFixed(2));
    } catch (e: any) {
      console.error(e);
      setError(e?.reason || e?.message || "İşlem sırasında hata oluştu.");
    } finally {
      setLoading(false);
    }
  }

  // ---------------------------------------------------------
  // UI
  // ---------------------------------------------------------
  return (
    <main className="min-h-screen bg-slate-950 text-slate-50">
      <div className="mx-auto max-w-5xl px-5 pt-8">
        {/* HEADER */}
        <header className="mb-8 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-xl font-semibold text-emerald-400">
              Auxite Admin · Spread Panel
            </h1>
            <p className="mt-1 text-xs text-slate-400">
              Canlı USD/kg, USD/g ve USD/oz fiyat &amp; spread yönetimi
              (AUXG / AUXS / AUXPT / AUXPD).
            </p>
          </div>

          <div className="flex flex-col items-start gap-1 text-xs sm:items-end">
            <button
              onClick={connectWallet}
              className="rounded-full border border-emerald-500 px-3 py-1 text-[11px] text-emerald-300 hover:bg-emerald-500/10"
            >
              {connectedAddress
                ? `Bağlandı: ${connectedAddress.slice(
                    0,
                    6
                  )}...${connectedAddress.slice(-4)}`
                : "Cüzdan Bağla"}
            </button>
            <span className="text-slate-500">Ağ: {network || "-"}</span>
          </div>
        </header>

        {/* CARD */}
        <section className="rounded-3xl border border-slate-800 bg-slate-900/80 px-7 py-6 shadow-lg">
          {/* Metal Tabs */}
          <div className="mb-5">
            <label className="mb-1 block text-xs font-semibold text-slate-300">
              Metal Seç
            </label>
            <div className="flex flex-wrap gap-2">
              {(Object.keys(METAL_LABELS) as MetalKey[]).map((m) => (
                <button
                  key={m}
                  onClick={() => {
                    setSelectedMetal(m);
                    setAskInput("");
                    setBidInput("");
                    setTxHash(null);
                    setError(null);
                  }}
                  className={
                    "rounded-full border px-3 py-1 text-[11px] " +
                    (selectedMetal === m
                      ? "border-emerald-500 bg-emerald-500/10 text-emerald-300"
                      : "border-slate-700 bg-slate-900 text-slate-300 hover:border-slate-500")
                  }
                >
                  {METAL_LABELS[m]}
                </button>
              ))}
            </div>
            <p className="mt-2 text-[11px] text-slate-500">
              Kontrat adresi:{" "}
              <span className="font-mono text-[10px] text-slate-300">
                {tokenAddress || "(ENV tanımlı değil)"}
              </span>
            </p>
          </div>

          {/* Mevcut spread (USD/kg) */}
          <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="rounded-2xl border border-slate-800 bg-slate-950/40 p-4 text-xs">
              <div className="text-slate-400">Mevcut ASK spread (USD/kg)</div>
              <div className="mt-1 text-xl font-semibold text-emerald-400">
                {currentAskSpreadUsdKg}
              </div>
            </div>

            <div className="rounded-2xl border border-slate-800 bg-slate-950/40 p-4 text-xs">
              <div className="text-slate-400">Mevcut BID spread (USD/kg)</div>
              <div className="mt-1 text-xl font-semibold text-rose-400">
                {currentBidSpreadUsdKg}
              </div>
            </div>
          </div>

          {/* USD/g */}
          <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="rounded-2xl border border-slate-800 bg-slate-950/40 p-4 text-xs">
              <div className="text-slate-400">ASK (USD/g)</div>
              <div className="mt-1 text-lg font-semibold text-emerald-400">
                {gramAsk}
              </div>
            </div>

            <div className="rounded-2xl border border-slate-800 bg-slate-950/40 p-4 text-xs">
              <div className="text-slate-400">BID (USD/g)</div>
              <div className="mt-1 text-lg font-semibold text-rose-400">
                {gramBid}
              </div>
            </div>
          </div>

          {/* USD/oz */}
          <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="rounded-2xl border border-slate-800 bg-slate-950/40 p-4 text-xs">
              <div className="text-slate-400">ASK (USD/oz)</div>
              <div className="mt-1 text-lg font-semibold text-emerald-400">
                {ozAsk}
              </div>
            </div>

            <div className="rounded-2xl border border-slate-800 bg-slate-950/40 p-4 text-xs">
              <div className="text-slate-400">BID (USD/oz)</div>
              <div className="mt-1 text-lg font-semibold text-rose-400">
                {ozBid}
              </div>
            </div>
          </div>

          {/* Oz Faktörü */}
          <div className="mb-6">
            <label className="mb-1 block text-xs text-slate-300">
              Oz Faktörü (1 oz kaç gram?)
            </label>
            <input
              type="number"
              step="0.0000001"
              value={ozFactor}
              onChange={(e) => setOzFactor(Number(e.target.value))}
              className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-slate-100 outline-none focus:border-emerald-500"
            />
            <p className="mt-1 text-[11px] text-slate-500">
              Varsayılan: 31.1034768 — değiştirilirse USD/oz hesaplaması anında
              güncellenir.
            </p>
          </div>

          {/* Yeni spread inputları */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 mb-6">
            <div>
              <label className="mb-1 block text-xs text-slate-300">
                Yeni ASK spread (USD/kg)
              </label>
              <input
                type="number"
                step="0.01"
                value={askInput}
                onChange={(e) => setAskInput(e.target.value)}
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-slate-100 outline-none focus:border-emerald-500"
                placeholder="Örn: 10"
              />
            </div>

            <div>
              <label className="mb-1 block text-xs text-slate-300">
                Yeni BID spread (USD/kg)
              </label>
              <input
                type="number"
                step="0.01"
                value={bidInput}
                onChange={(e) => setBidInput(e.target.value)}
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-slate-100 outline-none focus:border-rose-500"
                placeholder="Örn: 100"
              />
            </div>
          </div>

          {error && (
            <div className="mb-4 rounded-xl border border-red-500/40 bg-red-500/10 px-3 py-2 text-[11px] text-red-200">
              {error}
            </div>
          )}

          {txHash && (
            <div className="mb-4 rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-3 py-2 text-[11px] text-emerald-200">
              Tx: {txHash}
            </div>
          )}

          <div className="flex justify-end">
            <button
              onClick={handleUpdate}
              disabled={loading}
              className="rounded-full bg-emerald-500 px-6 py-2 text-xs font-semibold text-white hover:bg-emerald-400 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {loading ? "Güncelleniyor…" : "Spread Güncelle"}
            </button>
          </div>
        </section>
      </div>
    </main>
  );
}
