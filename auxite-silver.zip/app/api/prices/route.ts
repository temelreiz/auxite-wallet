// app/api/prices/route.ts
import { NextResponse } from "next/server";

const API_URL = `${process.env.NEXT_PUBLIC_API_BASE}/api/prices`;

export const revalidate = 0;

export async function GET() {
  try {
    const res = await fetch(API_URL, {
      method: "GET",
      headers: { Accept: "application/json" },
      cache: "no-store",
    });

    const text = await res.text();

    if (!res.ok) {
      return NextResponse.json(
        {
          ok: false,
          error: text || `HTTP ${res.status}`,
        },
        { status: 500 }
      );
    }

    let json;
    try {
      json = JSON.parse(text);
    } catch {
      return NextResponse.json(
        { ok: false, error: "Invalid JSON from upstream", raw: text },
        { status: 500 }
      );
    }

    return NextResponse.json(json);
  } catch (err: any) {
    return NextResponse.json(
      { ok: false, error: err.message ?? "unknown error" },
      { status: 500 }
    );
  }
}
