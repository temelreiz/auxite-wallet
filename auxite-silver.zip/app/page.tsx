"use client";

import { useState } from "react";
import MetalPriceGrid from "@/components/MetalPriceGrid";
import TopNav from "@/components/TopNav";
import TradePanel from "@/components/TradePanel";
import WalletConnectModal from "@/components/WalletConnectModal";
import type { MetalId } from "@/lib/metals";
import MarketOverview from "@/components/MarketOverview";

export type UiLang = "tr" | "en";
export type UiTheme = "dark" | "light";

type ActiveTab = "markets" | "leasing";

export default function HomePage() {
  const [lang, setLang] = useState<UiLang>("en");
  const [theme, setTheme] = useState<UiTheme>("dark");
  const [activeTab, setActiveTab] = useState<ActiveTab>("markets");

  const [walletModalOpen, setWalletModalOpen] = useState(false);

  const [tradeState, setTradeState] = useState<{
    metalId: MetalId | null;
    side: "BUY" | "SELL";
  }>({
    metalId: null,
    side: "BUY",
  });

  const isDark = theme === "dark";

  const pageBgCls = isDark
    ? "min-h-screen bg-black text-slate-50"
    : "min-h-screen bg-slate-50 text-slate-900";

  const shellCls =
    "mx-auto flex min-h-screen max-w-6xl flex-col px-4 pb-8 pt-4 sm:px-6 lg:px-8";

  return (
    <main className={pageBgCls}>
      <div className={shellCls}>
        {/* Üst Navbar */}
        <TopNav
          lang={lang}
          theme={theme}
          onLangChange={setLang}
          onThemeChange={setTheme}
          activeTab={activeTab}
          onTabChange={setActiveTab}
          onOpenWalletModal={() => setWalletModalOpen(true)}
        />

        {/* MARKETS TAB */}
        {activeTab === "markets" && (
          <>
            {/* Fiyat kartları */}
            <MetalPriceGrid
              lang={lang}
              theme={theme}
              onSelectTrade={(metalId, side) =>
                setTradeState({ metalId, side })
              }
            />

            {/* Alt grid: Market Overview + Risk/Correlation + Allocation + Yield */}
            <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
              {/* Market Overview (TradingView) */}
              <MarketOverview lang={lang} theme={theme} />

              {/* Risk & Correlation */}
              <div
                className={
                  (isDark
                    ? "rounded-3xl border border-slate-800 bg-slate-900/80"
                    : "rounded-3xl border border-slate-200 bg-white") +
                  " px-5 py-4 shadow-sm"
                }
              >
                <div className="mb-3 flex items-center justify-between text-xs text-slate-400">
                  <span>
                    {lang === "tr" ? "Risk ve Korelasyon" : "Risk & Correlation"}
                  </span>
                  <span className="text-[10px] uppercase tracking-[0.18em]">
                    {lang === "tr"
                      ? "Gelişmiş metrikler (yakında)"
                      : "Advanced metrics (soon)"}
                  </span>
                </div>

                <div className="flex h-64 items-center justify-center rounded-2xl border border-dashed border-slate-700/70 text-[11px] text-slate-500">
                  {lang === "tr"
                    ? "Volatilite, korelasyon ve diğer metrikler burada gösterilecek."
                    : "Volatility, correlation and other metrics will be shown here."}
                </div>
              </div>

              {/* Allocation Finder */}
              <div className="lg:col-span-2">
                <div
                  className={
                    (isDark
                      ? "rounded-3xl border border-slate-800 bg-slate-900/80"
                      : "rounded-3xl border border-slate-200 bg-white") +
                    " px-5 py-4 shadow-sm"
                  }
                >
                  <div className="mb-3 flex items-center justify-between text-xs text-slate-400">
                    <span>
                      {lang === "tr"
                        ? "Allocation Finder"
                        : "Allocation Finder"}
                    </span>
                    <span className="text-[10px] uppercase tracking-[0.18em]">
                      {lang === "tr"
                        ? "Optimal AUX portföyleri"
                        : "Build optimal AUX portfolios"}
                    </span>
                  </div>

                  <div className="flex h-40 items-center justify-center rounded-2xl border border-dashed border-slate-700/70 text-[11px] text-slate-500">
                    {lang === "tr"
                      ? "Hedef risk ve getiri seviyesine göre AUXG / AUXS / AUXPT / AUXPD dağılımını hesaplayacağımız araç burada olacak."
                      : "Tool to calculate AUXG / AUXS / AUXPT / AUXPD allocation based on target risk and return will live here."}
                  </div>
                </div>
              </div>

              {/* Auxite Yield */}
              <div className="lg:col-span-2">
                <div
                  className={
                    (isDark
                      ? "rounded-3xl border border-emerald-500/40 bg-emerald-950/40"
                      : "rounded-3xl border border-emerald-400 bg-emerald-50") +
                    " px-5 py-4 shadow-sm"
                  }
                >
                  <div className="mb-3 flex items-center justify-between text-xs text-emerald-500">
                    <span>Auxite Yield</span>
                    <span className="text-[10px] uppercase tracking-[0.18em]">
                      {lang === "tr"
                        ? "Yeni getiri ürünleri"
                        : "Upcoming yield products"}
                    </span>
                  </div>

                  <p className="text-[11px] text-emerald-100/80">
                    {lang === "tr"
                      ? "Auxite ekosistemindeki faiz, gelir paylaşımı ve strateji ürünlerini burada tek ekranda göstereceğiz."
                      : "We will show Auxite ecosystem yield, revenue-sharing and strategy products here in a single dashboard."}
                  </p>

                  <div className="mt-4 flex h-40 items-center justify-center rounded-2xl border border-dashed border-emerald-500/40 text-[11px] text-emerald-200/80">
                    {lang === "tr"
                      ? "Auxite Yield arayüzü hazırlanıyor."
                      : "Auxite Yield UI is under construction."}
                  </div>
                </div>
              </div>
            </div>
          </>
        )}

        {/* LEASING TAB */}
        {activeTab === "leasing" && (
          <section className="mt-6">
            <div
              className={
                (isDark
                  ? "rounded-3xl border border-emerald-500/40 bg-emerald-950/40"
                  : "rounded-3xl border border-emerald-500/40 bg-emerald-50") +
                " px-5 py-4 shadow-sm"
              }
            >
              <div className="mb-3 flex items-center justify-between text-xs text-emerald-500">
                <span>{lang === "tr" ? "Auxite Leasing" : "Auxite Leasing"}</span>
                <span className="text-[10px] uppercase tracking-[0.18em]">
                  {lang === "tr"
                    ? "Kira / lease ürünleri"
                    : "Lease / yield products"}
                </span>
              </div>

              <p className="text-[11px] text-emerald-100/80">
                {lang === "tr"
                  ? "Auxite ekosistemindeki lease / kira ürünlerini ve portföy bazlı leasing stratejilerini ve getirileri burada göstereceğiz."
                  : "This section will show lease products in the Auxite ecosystem and portfolio-based leasing strategies and returns."}
              </p>

              <div className="mt-4 flex h-40 items-center justify-center rounded-2xl border border-dashed border-emerald-500/40 text-[11px] text-emerald-200/80">
                {lang === "tr"
                  ? "Leasing arayüzü hazırlanıyor."
                  : "Leasing UI is under construction."}
              </div>
            </div>
          </section>
        )}

        {/* Trade panel */}
        <TradePanel
          open={!!tradeState.metalId}
          onClose={() =>
            setTradeState({
              metalId: null,
              side: "BUY",
            })
          }
          metalId={tradeState.metalId}
          side={tradeState.side}
          lang={lang}
        />

        {/* Wallet connect modal */}
        <WalletConnectModal
          open={walletModalOpen}
          onClose={() => setWalletModalOpen(false)}
          lang={lang}
        />
      </div>
    </main>
  );
}
