"use client";

import { useEffect, useRef, useState } from "react";
import { METALS, type MetalId } from "@/lib/metals";

export type PriceDirection = "up" | "down" | "same";

export interface MetalPrice {
  id: MetalId;
  symbol: string;
  name: string;
  price: number | null;
}

type PricesMap = Record<MetalId, number | null>;
type DirectionsMap = Record<MetalId, PriceDirection>;
type HistoryMap = Record<MetalId, number[]>;

interface UseMetalsPricesResult {
  prices: PricesMap;
  directions: DirectionsMap;
  history: HistoryMap;
  loading: boolean;
  error: string | null;
  lastUpdated: Date | null;
}

/**
 * Başlangıçta tüm metaller için fiyatları null yapan yardımcı fonksiyon.
 */
function createInitialPrices(): PricesMap {
  return METALS.reduce((acc, metal) => {
    acc[metal.id] = null;
    return acc;
  }, {} as PricesMap);
}

/**
 * Başlangıçta tüm metaller için yönü "same" yapan yardımcı fonksiyon.
 */
function createInitialDirections(): DirectionsMap {
  return METALS.reduce((acc, metal) => {
    acc[metal.id] = "same";
    return acc;
  }, {} as DirectionsMap);
}

/**
 * Başlangıçta tüm metaller için boş history dizisi oluşturan yardımcı fonksiyon.
 */
function createInitialHistory(): HistoryMap {
  return METALS.reduce((acc, metal) => {
    acc[metal.id] = [];
    return acc;
  }, {} as HistoryMap);
}

export function useMetalsPrices(): UseMetalsPricesResult {
  const [prices, setPrices] = useState<PricesMap>(() => createInitialPrices());
  const [directions, setDirections] = useState<DirectionsMap>(() =>
    createInitialDirections()
  );
  const [history, setHistory] = useState<HistoryMap>(() =>
    createInitialHistory()
  );
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  // Son gelen fiyatları saklayıp yön (up/down/same) hesaplamak için
  const lastPricesRef = useRef<PricesMap | null>(null);

  useEffect(() => {
    let isMounted = true;

    async function fetchPrices() {
      try {
        setError(null);
        // Gerekirse buradaki endpoint’i kendi API’ne göre değiştir
        const res = await fetch("/api/prices");
        if (!res.ok) {
          throw new Error(`Fiyatlar alınamadı (HTTP ${res.status})`);
        }

        const data = (await res.json()) as Record<
          MetalId,
          { price: number }
        >;

        if (!isMounted) return;

        setPrices((prev) => {
          const next: PricesMap = { ...prev };

          METALS.forEach((metal) => {
            const current = data[metal.id]?.price ?? null;
            next[metal.id] = current;
          });

          return next;
        });

        // Yön ve history güncelle
        setDirections((prevDirections) => {
          const nextDirections: DirectionsMap = { ...prevDirections };
          const lastPrices = lastPricesRef.current;

          METALS.forEach((metal) => {
            const id = metal.id;
            const newPrice = data[id]?.price ?? null;
            const oldPrice = lastPrices?.[id] ?? null;

            if (newPrice == null || oldPrice == null) {
              nextDirections[id] = "same";
              return;
            }

            if (newPrice > oldPrice) {
              nextDirections[id] = "up";
            } else if (newPrice < oldPrice) {
              nextDirections[id] = "down";
            } else {
              nextDirections[id] = "same";
            }
          });

          return nextDirections;
        });

        setHistory((prevHistory) => {
          const nextHistory: HistoryMap = { ...prevHistory };

          METALS.forEach((metal) => {
            const id = metal.id;
            const price = data[id]?.price ?? null;
            if (price == null) return;

            const prevList = nextHistory[id] ?? [];
            // Son 50 kaydı tutalım (istersen değiştir)
            nextHistory[id] = [...prevList, price].slice(-50);
          });

          return nextHistory;
        });

        // lastPricesRef’i güncelle
        const snapshot: PricesMap = createInitialPrices();
        METALS.forEach((metal) => {
          const id = metal.id;
          snapshot[id] = data[id]?.price ?? null;
        });
        lastPricesRef.current = snapshot;

        setLastUpdated(new Date());
        setLoading(false);
      } catch (e: any) {
        if (!isMounted) return;
        setError(e?.message ?? "Fiyatlar alınırken bir hata oluştu");
        setLoading(false);
      }
    }

    // İlk yüklemede çek
    fetchPrices();

    // İstersen periyodik polling
    const interval = setInterval(fetchPrices, 10_000); // 10 saniyede bir
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  return {
    prices,
    directions,
    history,
    loading,
    error,
    lastUpdated,
  };
}
