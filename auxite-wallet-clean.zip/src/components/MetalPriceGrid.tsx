"use client";

import type { UiLang, UiTheme } from "@/app/page";
import { METALS, type MetalId } from "@/lib/metals";
import {
  useMetalsPrices,
  type MetalPrice,
  type PriceDirection,
} from "@/hooks/useMetalsPrices";
import Sparkline from "@/components/Sparkline";

type Props = {
  lang: UiLang;
  theme: UiTheme;
  metals?: MetalPrice[]; // Şimdilik tip kalsın, aşağıda kullanmıyoruz
  onSelectTrade?: (metalId: MetalId, side: "BUY" | "SELL") => void;
};

function formatPrice(
  v: number | undefined,
  lang: UiLang,
  minFrac = 3,
  maxFrac = 3
) {
  if (!v || !Number.isFinite(v) || v <= 0)
    return (0).toLocaleString(lang === "tr" ? "tr-TR" : "en-US", {
      minimumFractionDigits: minFrac,
      maximumFractionDigits: maxFrac,
    });

  return v.toLocaleString(lang === "tr" ? "tr-TR" : "en-US", {
    minimumFractionDigits: minFrac,
    maximumFractionDigits: maxFrac,
  });
}

// "up" | "down" | "same" → Sparkline: "UP" | "DOWN" | undefined
function mapDirection(dir: PriceDirection | undefined): string | undefined {
  if (dir === "up") return "UP";
  if (dir === "down") return "DOWN";
  return undefined;
}

export default function MetalPriceGrid({
  lang,
  theme,
  metals: _metalsProp, // Şu an kullanılmıyor, ileride istersen override için kullanabiliriz
  onSelectTrade,
}: Props) {
  const isDark = theme === "dark";

  const { prices, directions, history, loading, error, lastUpdated } =
    useMetalsPrices();

  // connectionStatus yoksa, loading/error üzerinden basit bir status üretiyoruz
  const connectionStatus: "connected" | "connecting" | "stale" =
    loading && !error
      ? "connecting"
      : !loading && !error
      ? "connected"
      : "stale";

  const statusDotCls =
    connectionStatus === "connected"
      ? "bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.9)]"
      : connectionStatus === "connecting"
      ? "bg-yellow-400"
      : "bg-amber-400";

  const statusLabel =
    connectionStatus === "connected"
      ? lang === "tr"
        ? "Bağlı"
        : "Connected"
      : connectionStatus === "connecting"
      ? lang === "tr"
        ? "Bağlanıyor…"
        : "Connecting…"
      : lang === "tr"
      ? "Veri eski olabilir"
      : "Data may be stale";

  const headerTitleCls = isDark
    ? "text-base md:text-lg font-semibold text-slate-50"
    : "text-base md:text-lg font-semibold text-slate-900";

  const headerSubCls = isDark
    ? "mt-1 text-[11px] text-slate-400"
    : "mt-1 text-[11px] text-slate-600";

  const symbolLabelCls = isDark
    ? "text-[11px] uppercase tracking-wide text-slate-400"
    : "text-[11px] uppercase tracking-wide text-slate-500";

  const nameTextCls = isDark
    ? "text-sm font-semibold text-slate-50"
    : "text-sm font-semibold text-slate-900";

  const labelUnitCls = "text-[10px] text-slate-500";

  const bidAskTextCls = isDark
    ? "mt-0.5 text-[10px] text-slate-500"
    : "mt-0.5 text-[10px] text-slate-600";

  const cardCls = isDark
    ? "flex flex-col rounded-2xl border border-slate-800 bg-gradient-to-br from-slate-900/95 via-slate-900/90 to-black/90 px-4 py-3 shadow-sm hover:border-emerald-400/60 hover:shadow-[0_0_30px_rgba(16,185,129,0.35)] transition"
    : "flex flex-col rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-sm hover:border-emerald-500/60 hover:shadow-lg transition";

  const sparklineBoxCls = isDark
    ? "my-3 h-16 w-full rounded-xl bg-slate-900/80 border border-slate-800/70 px-1.5 py-1"
    : "my-3 h-16 w-full rounded-xl bg-slate-50 border border-slate-200 px-1.5 py-1";

  const priceBaseCls =
    "text-2xl md:text-3xl font-semibold leading-none drop-shadow-[0_0_10px_rgba(0,0,0,0.7)]";

  return (
    <section className="mt-6">
      {/* header */}
      <div className="mb-4 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className={headerTitleCls}>Auxite Wallet</h2>
          <p className={headerSubCls}>
            {lang === "tr"
              ? "Canlı metal fiyatları, Auxite tokenları ve işlem arayüzü."
              : "Live metal prices, Auxite tokens and trading interface."}
          </p>
        </div>

        <div className="flex flex-col items-start gap-1 sm:items-end">
          <div className="flex items-center gap-2 text-[11px] text-slate-500">
            <span
              className={`inline-flex h-2 w-2 rounded-full ${statusDotCls}`}
            />
            <span>{statusLabel}</span>
          </div>
          {lastUpdated && (
            <div className="text-[10px] text-slate-500">
              {lang === "tr" ? "Son günleme: " : "Last update: "}
              {new Date(lastUpdated).toLocaleTimeString(
                lang === "tr" ? "tr-TR" : "en-US",
                { hour: "2-digit", minute: "2-digit", second: "2-digit" }
              )}
            </div>
          )}
          {loading && (
            <p className="text-[11px] text-slate-500">
              {lang === "tr" ? "Fiyatlar yükleniyor…" : "Loading prices…"}
            </p>
          )}
          {!loading && error && (
            <p className="text-[11px] text-red-500">
              {lang === "tr" ? "Fiyat hatası: " : "Price error: "}
              {error}
            </p>
          )}
        </div>
      </div>

      {/* cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {METALS.map((m) => {
          const dir = directions[m.id] ?? "same";
          const histRaw = history[m.id] || [];

          // Hook fiyatı USD/oz → USD/g çeviriyoruz
          const pricePerOz = prices[m.id] ?? null;
          const ask =
            pricePerOz != null ? pricePerOz / 31.1034768 : undefined;
          const bid = ask; // İstersen burada küçük bir spread uygulayabiliriz

          const askStr = formatPrice(ask, lang);
          const bidStr = formatPrice(bid, lang);

          const priceCls =
            priceBaseCls +
            " " +
            (dir === "up"
              ? isDark
                ? "text-emerald-400"
                : "text-emerald-600"
              : dir === "down"
              ? isDark
                ? "text-red-400"
                : "text-red-600"
              : isDark
              ? "text-slate-200"
              : "text-slate-600");

          // Sparkline için de istersen USD/g’ye çevirebilirsin; ölçek fark etmiyor ama istersen:
          const hist =
            pricePerOz != null
              ? histRaw.map((v) => v / 31.1034768)
              : histRaw;

          return (
            <article key={m.id} className={cardCls}>
              {/* üst satır */}
              <div className="mb-2 flex items-center justify-between">
                <div>
                  <div className={symbolLabelCls}>{m.symbol}</div>
                  <div className={nameTextCls}>{m.name}</div>
                </div>
                <div className="text-right">
                  <div className={labelUnitCls}>USD/g</div>
                  <div className={priceCls}>{askStr}</div>
                  <div className={bidAskTextCls}>
                    {lang === "tr" ? "Alış / Satış" : "Bid / Ask"} {bidStr} /{" "}
                    {askStr}
                  </div>
                </div>
              </div>

              {/* mini grafik */}
              <div className={sparklineBoxCls}>
                <Sparkline
                  points={hist}
                  theme={theme}
                  direction={mapDirection(dir)}
                />
              </div>

              {/* butonlar */}
              <div className="mt-auto flex gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => onSelectTrade?.(m.id, "BUY")}
                  className="flex-1 rounded-full bg-emerald-500 py-1.5 text-center text-xs font-semibold text-white transition hover:bg-emerald-400"
                >
                  {lang === "tr" ? "Al (Buy)" : "Buy"}
                </button>
                <button
                  type="button"
                  onClick={() => onSelectTrade?.(m.id, "SELL")}
                  className="flex-1 rounded-full bg-red-500 py-1.5 text-center text-xs font-semibold text-white transition hover:bg-red-400"
                >
                  {lang === "tr" ? "Sat (Sell)" : "Sell"}
                </button>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}
