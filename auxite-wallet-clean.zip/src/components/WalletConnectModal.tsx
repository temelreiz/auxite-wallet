// src/components/WalletConnectModal.tsx
"use client";

type Props = {
  open: boolean;
  onClose: () => void;
  lang: "tr" | "en";
};

const CONNECTORS = [
  { id: "metamask", label: "MetaMask" },
  { id: "walletconnect", label: "WalletConnect" },
  { id: "coinbase", label: "Coinbase Wallet" },
  { id: "safe", label: "Safe (Gnosis Safe)" },
];

export default function WalletConnectModal({ open, onClose, lang }: Props) {
  if (!open) return null;

  const t = (key: string) => {
    const tr: Record<string, string> = {
      title: "Cüzdan Seç",
      desc: "Bağlamak istediğiniz cüzdanı seçin.",
    };
    const en: Record<string, string> = {
      title: "Select Wallet",
      desc: "Choose which wallet you want to connect.",
    };
    return (lang === "tr" ? tr : en)[key];
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="w-full max-w-sm rounded-3xl border border-zinc-800 bg-zinc-950/95 p-5 shadow-xl">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <div className="text-xs uppercase tracking-[0.2em] text-zinc-500">
              Wallet
            </div>
            <div className="text-sm font-semibold text-zinc-50">
              {t("title")}
            </div>
            <div className="mt-1 text-[11px] text-zinc-500">{t("desc")}</div>
          </div>
          <button
            className="rounded-full px-2 py-1 text-xs text-zinc-400 hover:bg-zinc-800"
            onClick={onClose}
          >
            ✕
          </button>
        </div>

        <div className="space-y-2">
          {CONNECTORS.map((c) => (
            <button
              key={c.id}
              type="button"
              className="flex w-full items-center justify-between rounded-2xl border border-zinc-800 bg-zinc-900/70 px-3 py-2 text-sm text-zinc-100 hover:border-emerald-400/60 hover:bg-zinc-900"
              // TODO: buraya gerçek wagmi/reown connect handler gelecek
              onClick={() => {
                console.log("connect", c.id);
                onClose();
              }}
            >
              <span>{c.label}</span>
              <span className="text-[11px] text-zinc-500">
                {lang === "tr" ? "Çoklu hesap" : "Multi-account"}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
