"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAccount } from "wagmi";
import { useState, useEffect } from "react";

const navItems = [
  { href: "/", label: "Dashboard" },
  { href: "/buy", label: "Buy" },
  { href: "/sell", label: "Sell" },
  { href: "/safe", label: "Safe" },
  { href: "/leasing", label: "Leasing" },
  { href: "/settings", label: "Settings" },
];

export default function Nav() {
  const pathname = usePathname();
  const { address } = useAccount();

  const [lang, setLang] = useState<"tr" | "en">("en");
  const [theme, setTheme] = useState<"light" | "dark">("dark");

  // 👇 Hydration mismatch çözümü
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    setMounted(true);
  }, []);

  const shortAddress =
    mounted && address ? `${address.slice(0, 6)}…${address.slice(-4)}` : null;

  const statusLabel = shortAddress ? "Connected:" : "Wallet:";
  const statusValue = shortAddress ?? "Not connected";

  return (
    <header className="w-full border-b border-black/5 dark:border-white/10 bg-white/80 dark:bg-slate-950/80 backdrop-blur">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-4 px-5 py-3">
        {/* Sol taraf: logo + menü */}
        <div className="flex items-center gap-6">
          <div className="flex flex-col">
            <span className="text-sm font-semibold tracking-tight">
              Auxite Wallet
            </span>
            <span className="text-[11px] text-slate-500 dark:text-slate-400">
              Gold • Silver • Platinum • Palladium
            </span>
          </div>

          <nav className="hidden md:flex items-center gap-2 text-sm">
            {navItems.map((item) => {
              const active = pathname === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={
                    "px-3 py-1 rounded-full transition text-xs md:text-sm " +
                    (active
                      ? "bg-emerald-400 text-slate-900 shadow-sm"
                      : "text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800")
                  }
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Sağ taraf: dil / tema / cüzdan */}
        <div className="flex items-center gap-2 text-xs md:text-sm">
          {/* Dil toggle (görsel) */}
          <div className="flex rounded-full border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 overflow-hidden">
            <button
              type="button"
              onClick={() => setLang("tr")}
              className={
                "px-3 py-1 " +
                (lang === "tr"
                  ? "bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900"
                  : "text-slate-600 dark:text-slate-300")
              }
            >
              Türkçe
            </button>
            <button
              type="button"
              onClick={() => setLang("en")}
              className={
                "px-3 py-1 " +
                (lang === "en"
                  ? "bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900"
                  : "text-slate-600 dark:text-slate-300")
              }
            >
              English
            </button>
          </div>

          {/* Tema toggle (şimdilik sadece görsel) */}
          <button
            type="button"
            onClick={() =>
              setTheme((prev) => (prev === "dark" ? "light" : "dark"))
            }
            className="hidden md:inline-flex items-center px-3 py-1 rounded-full border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-900 text-xs"
          >
            {theme === "dark" ? "Dark Mode" : "Light Mode"}
          </button>

          {/* Cüzdan durumu */}
          <div className="flex items-center gap-2">
            <span className="hidden md:inline text-[11px] text-slate-500 dark:text-slate-400">
              {statusLabel}
            </span>
            <span className="px-3 py-1 rounded-full text-[11px] md:text-xs font-medium bg-emerald-500/10 text-emerald-700 border border-emerald-500/40 dark:bg-emerald-500/15 dark:text-emerald-300">
              {statusValue}
            </span>
          </div>
        </div>
      </div>

      {/* Mobil menü */}
      <nav className="md:hidden px-4 pb-3 flex flex-wrap gap-2 text-xs">
        {navItems.map((item) => {
          const active = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={
                "px-3 py-1 rounded-full transition " +
                (active
                  ? "bg-emerald-400 text-slate-900 shadow-sm"
                  : "text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800")
              }
            >
              {item.label}
            </Link>
          );
        })}
      </nav>
    </header>
  );
}
