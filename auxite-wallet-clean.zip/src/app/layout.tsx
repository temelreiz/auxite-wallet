import "./globals.css";
import type { Metadata } from "next";
import { Inter } from "next/font/google";

import Web3Provider from "@/context/Web3Provider";
import Nav from "@/components/Nav";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Auxite Wallet",
  description: "RWA metal token cüzdanı",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="tr">
      <body className={inter.className}>
        <Web3Provider>
          <div className="min-h-screen bg-slate-950 text-slate-50 dark:bg-slate-950 dark:text-slate-50">
            {/* Üst navigasyon */}
            <Nav />

            {/* Sayfa içerikleri */}
            <main className="max-w-6xl mx-auto px-4 pt-4 pb-10">
              {children}
            </main>
          </div>
        </Web3Provider>
      </body>
    </html>
  );
}
