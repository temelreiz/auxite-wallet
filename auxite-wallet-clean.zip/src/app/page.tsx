"use client";

import { useState } from "react";
import MetalPriceGrid from "@/components/MetalPriceGrid";
import TopNav from "@/components/TopNav";
import TradePanel from "@/components/TradePanel";
import WalletConnectModal from "@/components/WalletConnectModal";
import type { MetalId } from "@/lib/metals";

export type UiLang = "tr" | "en";
export type UiTheme = "dark" | "light";

type ActiveTab = "markets" | "leasing";

export default function HomePage() {
  const [lang, setLang] = useState<UiLang>("en");
  const [theme, setTheme] = useState<UiTheme>("dark");
  const [activeTab, setActiveTab] = useState<ActiveTab>("markets");

  const [walletModalOpen, setWalletModalOpen] = useState(false);

  const [tradeState, setTradeState] = useState<{
    metalId: MetalId | null;
    side: "BUY" | "SELL";
  }>({
    metalId: null,
    side: "BUY",
  });

  const isDark = theme === "dark";

  const pageBgCls = isDark
    ? "min-h-screen bg-black text-slate-50"
    : "min-h-screen bg-slate-50 text-slate-900";

  const shellCls = isDark
    ? "mx-auto flex min-h-screen max-w-6xl flex-col px-4 pb-8 pt-4 sm:px-6 lg:px-8"
    : "mx-auto flex min-h-screen max-w-6xl flex-col px-4 pb-8 pt-4 sm:px-6 lg:px-8";

  return (
    <main className={pageBgCls}>
      <div className={shellCls}>
        {/* Üst Navbar */}
        <TopNav
          lang={lang}
          theme={theme}
          onLangChange={setLang}
          onThemeChange={setTheme}
          activeTab={activeTab}
          onTabChange={setActiveTab}
          onOpenWalletModal={() => setWalletModalOpen(true)}
        />

        {/* Ana içerik */}
        {activeTab === "markets" && (
          <>
            {/* Live prices + trade butonları */}
            <MetalPriceGrid
              lang={lang}
              theme={theme}
              onSelectTrade={(metalId, side) =>
                setTradeState({ metalId, side })
              }
            />

            {/* Alt kartlar */}
            <section className="mt-8 grid grid-cols-1 gap-4 md:grid-cols-2">
              {/* Market Overview */}
              <div
                className={
                  (isDark
                    ? "rounded-3xl border border-slate-800 bg-slate-900/80"
                    : "rounded-3xl border border-slate-200 bg-white") +
                  " px-5 py-4 shadow-sm"
                }
              >
                <div className="mb-3 flex items-center justify-between text-xs text-slate-400">
                  <span>
                    {lang === "tr" ? "Market Overview" : "Market Overview"}
                  </span>
                  <span className="text-[10px] uppercase tracking-[0.18em]">
                    Charts / TV integration
                  </span>
                </div>
                <div className="flex h-40 items-center justify-center rounded-2xl border border-dashed border-slate-700/70 text-[11px] text-slate-500">
                  {lang === "tr"
                    ? "AUXG / AUXS / AUXPT / AUXPD için grafik alanı."
                    : "Chart placeholder for AUXG / AUXS / AUXPT / AUXPD."}
                </div>
              </div>

              {/* Risk & Correlation */}
              <div
                className={
                  (isDark
                    ? "rounded-3xl border border-slate-800 bg-slate-900/80"
                    : "rounded-3xl border border-slate-200 bg-white") +
                  " px-5 py-4 shadow-sm"
                }
              >
                <div className="mb-3 flex items-center justify-between text-xs text-slate-400">
                  <span>
                    {lang === "tr"
                      ? "Risk & Correlation"
                      : "Risk & Correlation"}
                  </span>
                  <span className="text-[10px] uppercase tracking-[0.18em]">
                    {lang === "tr" ? "Gelişmiş metrikler (yakında)" : "Advanced metrics (soon)"}
                  </span>
                </div>
                <div className="flex h-40 items-center justify-center rounded-2xl border border-dashed border-slate-700/70 text-[11px] text-slate-500">
                  {lang === "tr"
                    ? "Volatilite, korelasyon ve diğer metrikler burada olacak."
                    : "Volatility, correlation and other metrics will be shown here."}
                </div>
              </div>
            </section>

            {/* Allocation Finder */}
            <section className="mt-6">
              <div
                className={
                  (isDark
                    ? "rounded-3xl border border-slate-800 bg-slate-900/80"
                    : "rounded-3xl border border-slate-200 bg-white") +
                  " px-5 py-4 shadow-sm"
                }
              >
                <div className="mb-2 flex items-center justify-between text-xs text-slate-400">
                  <span>
                    {lang === "tr"
                      ? "Allocation Finder"
                      : "Allocation Finder"}
                  </span>
                  <span className="text-[10px] uppercase tracking-[0.18em]">
                    {lang === "tr"
                      ? "Optimal AUX portföyleri"
                      : "Build optimal AUX portfolios"}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500">
                  {lang === "tr"
                    ? "Hedef risk ve getiri seviyesine göre AUXG / AUXS / AUXPT / AUXPD dağılımını hesaplayacağımız araç burada olacak."
                    : "Tool to calculate AUXG / AUXS / AUXPT / AUXPD allocation based on target risk and return will live here."}
                </p>
                <div className="mt-4 flex h-24 items-center justify-center rounded-2xl border border-dashed border-slate-700/70 text-[11px] text-slate-500">
                  {lang === "tr"
                    ? "Allocation Finder arayüzü yakında."
                    : "Allocation Finder UI coming soon."}
                </div>
              </div>
            </section>
          </>
        )}

        {activeTab === "leasing" && (
          <section className="mt-6">
            <div
              className={
                (isDark
                  ? "rounded-3xl border border-emerald-500/40 bg-emerald-950/40"
                  : "rounded-3xl border border-emerald-500/40 bg-emerald-50") +
                " px-5 py-4 shadow-sm"
              }
            >
              <div className="mb-2 flex items-center justify-between">
                <div className="text-sm font-semibold text-emerald-100">
                  Leasing (Auxite Yield)
                </div>
                <span className="text-[10px] uppercase tracking-[0.18em] text-emerald-300">
                  {lang === "tr"
                    ? "Regülasyon odaklı"
                    : "Regulation focused"}
                </span>
              </div>
              <p className="text-[11px] text-emerald-100/80">
                {lang === "tr"
                  ? "Auxite ekosistemindeki lease / kira ürünleri bu sekmede, ayrı bir modül olarak çalışacak. Burada portföy bazlı leasing stratejilerini ve getirileri göstereceğiz."
                  : "Lease products in the Auxite ecosystem will live here as a separate module. This section will show portfolio-based leasing strategies and returns."}
              </p>
              <div className="mt-4 flex h-28 items-center justify-center rounded-2xl border border-dashed border-emerald-500/40 text-[11px] text-emerald-200/80">
                {lang === "tr"
                  ? "Leasing arayüzü hazırlanıyor."
                  : "Leasing UI is under construction."}
              </div>
            </div>
          </section>
        )}

        {/* Trade panel */}
        <TradePanel
          open={!!tradeState.metalId}
          onClose={() =>
            setTradeState({
              metalId: null,
              side: "BUY",
            })
          }
          metalId={tradeState.metalId}
          side={tradeState.side}
          lang={lang}
        />

        {/* Wallet connect modal */}
        <WalletConnectModal
          open={walletModalOpen}
          onClose={() => setWalletModalOpen(false)}
          lang={lang}
        />
      </div>
    </main>
  );
}
