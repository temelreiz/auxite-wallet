// src/app/api/gold/route.ts
import { NextResponse } from "next/server";

const GOLDAPI_KEY = process.env.GOLDAPI_KEY;
const GOLDAPI_BASE_URL = process.env.GOLDAPI_BASE_URL || "https://www.goldapi.io/api";
const GOLDAPI_SYMBOL = process.env.GOLDAPI_SYMBOL || "XAU/USD";

export async function GET() {
  if (!GOLDAPI_KEY) {
    return NextResponse.json(
      { error: "GOLDAPI_KEY is not configured" },
      { status: 500 }
    );
  }

  try {
    const res = await fetch(`${GOLDAPI_BASE_URL}/${encodeURIComponent(GOLDAPI_SYMBOL)}`, {
      headers: {
        "x-access-token": GOLDAPI_KEY,
        "Content-Type": "application/json",
      },
      // Bazen Next fetch caching sıkıntı çıkarıyor, no-store yapalım
      cache: "no-store",
    });

    if (!res.ok) {
      const text = await res.text();
      console.error("GoldAPI error:", res.status, text);
      return NextResponse.json(
        { error: "Failed to fetch from GoldAPI" },
        { status: 500 }
      );
    }

    const data = await res.json();

    // GoldAPI dökümantasyonuna uygun basit map
    // Varsayım: data.price, data.open_price gibi alanlar var
    const price = data.price ?? data.ask ?? data.bid ?? null;

    return NextResponse.json({
      price,
      open_price: data.open_price ?? null,
      high_price: data.high_price ?? null,
      low_price: data.low_price ?? null,
      currency: data.currency ?? "USD",
      timestamp: data.timestamp ?? Date.now() / 1000,
      raw: data,
    });
  } catch (err) {
    console.error("GoldAPI fetch exception:", err);
    return NextResponse.json(
      { error: "Exception while fetching GoldAPI" },
      { status: 500 }
    );
  }
}
