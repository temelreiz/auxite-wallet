"use client";

import { useState, useEffect } from "react";
import { useAccount, useWriteContract, useWaitForTransactionReceipt, useReadContract } from "wagmi";
import { parseUnits, erc20Abi } from "viem";
import { useStaking, METAL_IDS } from "@/hooks/useStaking";

// 6-language translations
const translations: Record<string, Record<string, string>> = {
  tr: {
    lockEarn: "Biriktir & Kazan",
    lockPeriod: "Biriktirme Süresi",
    month: "Ay",
    days: "gün",
    amount: "Miktar",
    balance: "Bakiye",
    lockSuccess: "Biriktirme Başarılı!",
    positionCreated: "Pozisyonunuz oluşturuldu.",
    approved: "Onaylandı",
    canLockNow: "Şimdi biriktirebilirsiniz.",
    infoNotice: "gün boyunca tokenleriniz biriktirilecektir. Süre sonunda anaparanız ve kazancınız otomatik olarak iade edilecektir.",
    approving: "Onaylanıyor...",
    approveToken: "Onayla",
    locking: "Biriktiriliyor...",
    cancel: "İptal",
    estimatedEarnings: "Tahmini Kazanç",
    afterPeriod: "Süre sonunda",
    apy: "APY",
    stakeCode: "Stake Kodu",
    copyCode: "Kopyala",
    copied: "Kopyalandı!",
    viewOnChain: "Blockchain'de Görüntüle",
    compounding: "Bileşik Faiz",
    compoundingDesc: "Kazançlar otomatik olarak anaparaya eklenir",
    txPending: "İşlem Onay Bekliyor...",
    txConfirming: "Blockchain'de Doğrulanıyor...",
    done: "Tamam",
  },
  en: {
    lockEarn: "Stake & Earn",
    lockPeriod: "Stake Period",
    month: "Mo",
    days: "days",
    amount: "Amount",
    balance: "Balance",
    lockSuccess: "Stake Successful!",
    positionCreated: "Your position has been created.",
    approved: "Approved",
    canLockNow: "You can now stake.",
    infoNotice: "days your tokens will be staked. Principal and earnings will be automatically returned after the period ends.",
    approving: "Approving...",
    approveToken: "Approve",
    locking: "Staking...",
    cancel: "Cancel",
    estimatedEarnings: "Estimated Earnings",
    afterPeriod: "After period",
    apy: "APY",
    stakeCode: "Stake Code",
    copyCode: "Copy",
    copied: "Copied!",
    viewOnChain: "View on Blockchain",
    compounding: "Auto-Compound",
    compoundingDesc: "Earnings automatically added to principal",
    txPending: "Transaction Pending...",
    txConfirming: "Confirming on Blockchain...",
    done: "Done",
  },
  de: {
    lockEarn: "Stake & Verdienen",
    lockPeriod: "Stake-Zeitraum",
    month: "Mo",
    days: "Tage",
    amount: "Betrag",
    balance: "Guthaben",
    lockSuccess: "Stake Erfolgreich!",
    positionCreated: "Ihre Position wurde erstellt.",
    approved: "Genehmigt",
    canLockNow: "Sie können jetzt staken.",
    infoNotice: "Tage werden Ihre Token gestaked. Kapital und Erträge werden nach Ablauf automatisch zurückgegeben.",
    approving: "Genehmigung...",
    approveToken: "Genehmigen",
    locking: "Staking...",
    cancel: "Abbrechen",
    estimatedEarnings: "Geschätzte Erträge",
    afterPeriod: "Nach der Periode",
    apy: "APY",
    stakeCode: "Stake-Code",
    copyCode: "Kopieren",
    copied: "Kopiert!",
    viewOnChain: "Auf Blockchain anzeigen",
    compounding: "Auto-Zinseszins",
    compoundingDesc: "Erträge werden automatisch zum Kapital hinzugefügt",
    txPending: "Transaktion ausstehend...",
    txConfirming: "Wird auf Blockchain bestätigt...",
    done: "Fertig",
  },
  fr: {
    lockEarn: "Stake & Gagner",
    lockPeriod: "Période de Stake",
    month: "Mois",
    days: "jours",
    amount: "Montant",
    balance: "Solde",
    lockSuccess: "Stake Réussi!",
    positionCreated: "Votre position a été créée.",
    approved: "Approuvé",
    canLockNow: "Vous pouvez maintenant staker.",
    infoNotice: "jours vos tokens seront stakés. Le capital et les gains seront automatiquement retournés après la période.",
    approving: "Approbation...",
    approveToken: "Approuver",
    locking: "Staking...",
    cancel: "Annuler",
    estimatedEarnings: "Gains Estimés",
    afterPeriod: "Après la période",
    apy: "APY",
    stakeCode: "Code de Stake",
    copyCode: "Copier",
    copied: "Copié!",
    viewOnChain: "Voir sur Blockchain",
    compounding: "Auto-Composition",
    compoundingDesc: "Les gains sont automatiquement ajoutés au capital",
    txPending: "Transaction en attente...",
    txConfirming: "Confirmation sur Blockchain...",
    done: "Terminé",
  },
  ar: {
    lockEarn: "تخزين واربح",
    lockPeriod: "فترة التخزين",
    month: "شهر",
    days: "يوم",
    amount: "المبلغ",
    balance: "الرصيد",
    lockSuccess: "تم التخزين بنجاح!",
    positionCreated: "تم إنشاء موقعك.",
    approved: "تمت الموافقة",
    canLockNow: "يمكنك الآن التخزين.",
    infoNotice: "يوم سيتم تخزين رموزك. سيتم إرجاع رأس المال والأرباح تلقائياً بعد انتهاء الفترة.",
    approving: "جاري الموافقة...",
    approveToken: "يتأكد",
    locking: "جاري التخزين...",
    cancel: "إلغاء",
    estimatedEarnings: "الأرباح المتوقعة",
    afterPeriod: "بعد الفترة",
    apy: "العائد السنوي",
    stakeCode: "رمز التخزين",
    copyCode: "نسخ",
    copied: "تم النسخ!",
    viewOnChain: "عرض على البلوكتشين",
    compounding: "فائدة مركبة تلقائية",
    compoundingDesc: "تضاف الأرباح تلقائياً إلى رأس المال",
    txPending: "المعاملة معلقة...",
    txConfirming: "جاري التأكيد على البلوكتشين...",
    done: "تم",
  },
  ru: {
    lockEarn: "Стейкинг и Заработок",
    lockPeriod: "Период Стейкинга",
    month: "Мес",
    days: "дней",
    amount: "Сумма",
    balance: "Баланс",
    lockSuccess: "Стейкинг Успешен!",
    positionCreated: "Ваша позиция создана.",
    approved: "Одобрено",
    canLockNow: "Теперь вы можете сделать стейкинг.",
    infoNotice: "дней ваши токены будут в стейкинге. Основная сумма и заработок будут автоматически возвращены после окончания периода.",
    approving: "Одобрение...",
    approveToken: "Одобрить",
    locking: "Стейкинг...",
    cancel: "Отмена",
    estimatedEarnings: "Расчетный Заработок",
    afterPeriod: "После периода",
    apy: "APY",
    stakeCode: "Код Стейкинга",
    copyCode: "Копировать",
    copied: "Скопировано!",
    viewOnChain: "Посмотреть в Блокчейне",
    compounding: "Автокомпаундинг",
    compoundingDesc: "Заработок автоматически добавляется к основной сумме",
    txPending: "Транзакция ожидает...",
    txConfirming: "Подтверждение в блокчейне...",
    done: "Готово",
  },
};

interface AllocationModalProps {
  isOpen: boolean;
  onClose: () => void;
  offer: {
    metal: string;
    name: string;
    icon: string;
    metalTokenAddress: string;
    periods: Array<{ months: number; days: number; apy: number }>;
    minAmount: number;
    maxAmount: number;
    tvl: number;
    contractAddress: string;
  } | null;
  lang: string;
}

// APY Visual Comparison
function APYVisual({ periods, selectedPeriod, onSelect, lang }: {
  periods: Array<{ months: number; days: number; apy: number }>;
  selectedPeriod: number;
  onSelect: (months: number) => void;
  lang: string;
}) {
  const t = translations[lang] || translations.en;
  const maxAPY = Math.max(...periods.map(p => p.apy));
  
  const getDays = (months: number, days?: number) => days || (months === 12 ? 365 : months * 30);
  
  return (
    <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
      {periods.map((period) => {
        const isSelected = selectedPeriod === period.months;
        const barHeight = (period.apy / maxAPY) * 100;
        const periodDays = getDays(period.months, period.days);
        
        return (
          <button
            key={period.months}
            onClick={() => onSelect(period.months)}
            className={`relative p-2 sm:p-3 rounded-lg border-2 transition-all ${
              isSelected 
                ? "border-emerald-500 bg-emerald-500/10 dark:bg-emerald-500/20" 
                : "border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 bg-white dark:bg-slate-800/50"
            }`}
          >
            <div className="h-8 sm:h-12 flex items-end justify-center mb-1.5 sm:mb-2">
              <div 
                className={`w-5 sm:w-6 rounded-t-md sm:rounded-t-lg transition-all ${
                  isSelected 
                    ? "bg-gradient-to-t from-emerald-500 to-emerald-400" 
                    : "bg-gradient-to-t from-slate-300 to-slate-200 dark:from-slate-600 dark:to-slate-500"
                }`}
                style={{ height: `${barHeight}%` }}
              />
            </div>
            
            <div className={`text-xs sm:text-sm font-bold whitespace-nowrap ${isSelected ? "text-emerald-500 dark:text-emerald-400" : "text-slate-700 dark:text-slate-300"}`}>
              {period.months} {t.month}
            </div>
            <div className="text-[9px] sm:text-[10px] text-slate-500 dark:text-slate-400">
              {periodDays} {t.days}
            </div>
            
            <div className={`mt-1 text-[11px] sm:text-xs font-semibold ${isSelected ? "text-emerald-600 dark:text-emerald-400" : "text-slate-600 dark:text-slate-400"}`}>
              {period.apy.toFixed(2)}%
            </div>

            {isSelected && (
              <div className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-emerald-500 flex items-center justify-center">
                <svg className="w-2 h-2 sm:w-2.5 sm:h-2.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                </svg>
              </div>
            )}
          </button>
        );
      })}
    </div>
  );
}

// Earnings Calculator
function EarningsCalculator({ amount, apy, days, metalSymbol, lang }: {
  amount: number;
  apy: number;
  days: number;
  metalSymbol: string;
  lang: string;
}) {
  const t = translations[lang] || translations.en;
  const earnings = (amount * apy * days) / (100 * 365);
  const total = amount + earnings;
  
  if (amount <= 0) return null;
  
  return (
    <div className="rounded-lg sm:rounded-xl bg-gradient-to-br from-emerald-500/10 to-cyan-500/10 dark:from-emerald-500/20 dark:to-cyan-500/20 border border-emerald-500/20 p-3 sm:p-4">
      <div className="flex items-center gap-2 mb-2 sm:mb-3">
        <svg className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
        </svg>
        <span className="text-xs sm:text-sm font-medium text-emerald-600 dark:text-emerald-400">
          {t.estimatedEarnings}
        </span>
      </div>
      
      <div className="grid grid-cols-2 gap-3 sm:gap-4">
        <div>
          <div className="text-[10px] sm:text-xs text-slate-500 dark:text-slate-400">{t.afterPeriod}</div>
          <div className="text-base sm:text-lg font-bold text-emerald-600 dark:text-emerald-400">
            +{earnings.toFixed(4)}g
          </div>
        </div>
        <div>
          <div className="text-[10px] sm:text-xs text-slate-500 dark:text-slate-400">Total</div>
          <div className="text-base sm:text-lg font-bold text-slate-800 dark:text-white">
            {total.toFixed(4)}g
          </div>
        </div>
      </div>
    </div>
  );
}

// Stake Code Display Component
function StakeCodeDisplay({ stakeCode, shortCode, txHash, lang }: {
  stakeCode: string;
  shortCode: string;
  txHash?: string;
  lang: string;
}) {
  const t = translations[lang] || translations.en;
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(shortCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const explorerUrl = txHash 
    ? `https://etherscan.io/tx/${txHash}` 
    : `https://etherscan.io/address/${process.env.NEXT_PUBLIC_STAKING_CONTRACT}`;

  return (
    <div className="rounded-lg sm:rounded-xl bg-gradient-to-br from-emerald-500/20 to-cyan-500/20 border border-emerald-500/30 p-3 sm:p-4 space-y-2 sm:space-y-3">
      <div>
        <div className="text-[10px] sm:text-xs text-emerald-600 dark:text-emerald-400 mb-1 font-medium">
          {t.stakeCode}
        </div>
        <div className="flex items-center gap-1.5 sm:gap-2">
          <code className="flex-1 px-2 sm:px-3 py-1.5 sm:py-2 rounded-lg bg-slate-900/50 text-emerald-400 font-mono text-xs sm:text-sm truncate">
            {shortCode}
          </code>
          <button
            onClick={handleCopy}
            className="px-2 sm:px-3 py-1.5 sm:py-2 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 text-xs sm:text-sm font-medium transition-colors flex items-center gap-1"
          >
            {copied ? (
              <>
                <svg className="w-3 h-3 sm:w-4 sm:h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span className="hidden sm:inline">{t.copied}</span>
              </>
            ) : (
              <>
                <svg className="w-3 h-3 sm:w-4 sm:h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
                <span className="hidden sm:inline">{t.copyCode}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {txHash && (
        <a
          href={explorerUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg bg-slate-800/50 hover:bg-slate-700/50 text-slate-300 text-xs sm:text-sm font-medium transition-colors"
        >
          <svg className="w-3 h-3 sm:w-4 sm:h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
          </svg>
          {t.viewOnChain}
        </a>
      )}
    </div>
  );
}

function AllocationModal({ isOpen, onClose, offer, lang }: AllocationModalProps) {
  const t = translations[lang] || translations.en;
  const { address, isConnected } = useAccount();
  
  // Staking hook
  const { 
    stake, 
    isStaking, 
    isStakeSuccess, 
    stakeHash,
    previewReward 
  } = useStaking();

  // Local state
  const [selectedPeriod, setSelectedPeriod] = useState(3);
  const [amount, setAmount] = useState("");
  const [compounding, setCompounding] = useState(false);
  const [resultStakeCode, setResultStakeCode] = useState<string | null>(null);
  const [resultShortCode, setResultShortCode] = useState<string | null>(null);

  const stakingContractAddress = process.env.NEXT_PUBLIC_STAKING_CONTRACT as `0x${string}`;
  const tokenAddress = offer?.metalTokenAddress as `0x${string}`;

  // Debug logs
  console.log("AllocationModal Debug:", {
    tokenAddress,
    stakingContractAddress,
    address,
    isOpen,
    offerMetal: offer?.metal, fullOffer: offer,
  });

  // Read token balance
  const { data: balanceData } = useReadContract({
    address: tokenAddress,
    abi: erc20Abi,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: { enabled: !!address && !!tokenAddress && isOpen },
  });

  // Read current allowance
  const { data: allowanceData, refetch: refetchAllowance } = useReadContract({
    address: tokenAddress,
    abi: erc20Abi,
    functionName: 'allowance',
    args: address && stakingContractAddress ? [address, stakingContractAddress] : undefined,
    query: { enabled: !!address && !!stakingContractAddress && !!tokenAddress && isOpen },
  });

  // Debug balance & allowance
  console.log("Balance/Allowance Debug:", {
    balanceData: balanceData?.toString(),
    balanceNum: balanceData ? Number(balanceData) / 1000 : 0,
    allowanceData: allowanceData?.toString(),
  });

  // Approve write contract
  const { 
    writeContract: writeApprove, 
    data: approveHash,
    isPending: isApprovePending,
    reset: resetApprove
  } = useWriteContract();

  // Wait for approve transaction
  const { isLoading: isApproveConfirming, isSuccess: isApproveSuccess } = useWaitForTransactionReceipt({
    hash: approveHash,
  });

  // Refetch allowance after approve success
  useEffect(() => {
    if (isApproveSuccess) {
      refetchAllowance();
    }
  }, [isApproveSuccess, refetchAllowance]);

  // Reset state when modal opens/closes
  useEffect(() => {
    if (isOpen) {
      setSelectedPeriod(3);
      setAmount("");
      setCompounding(false);
      setResultStakeCode(null);
      setResultShortCode(null);
      resetApprove();
    }
  }, [isOpen]);

  if (!isOpen || !offer) return null;

  // Calculate values
  const amountNum = parseFloat(amount) || 0;
  const amountInTokenUnits = BigInt(Math.floor(amountNum * 1000)); // 3 decimals
  const balanceNum = balanceData ? Number(balanceData) / 1000 : 0; // Convert from 3 decimals
  const currentAllowance = allowanceData ? Number(allowanceData) / 1000 : 0;
  const currentPeriod = offer.periods.find(p => p.months === selectedPeriod) || offer.periods[0];
  const periodDays = currentPeriod.days || (selectedPeriod === 12 ? 365 : selectedPeriod * 30);
  
  // Check if needs approval
  const needsApproval = amountNum > 0 && currentAllowance < amountNum;
  const isApproving = isApprovePending || isApproveConfirming;

  // Handle approve
  const handleApprove = () => {
    if (!address || !tokenAddress || !stakingContractAddress) return;

    writeApprove({
      address: tokenAddress,
      abi: erc20Abi,
      functionName: 'approve',
      args: [stakingContractAddress, amountInTokenUnits],
    });
  };

  // Handle stake
  const handleStake = async () => {
    if (!address || !offer) return;

    try {
      const metalSymbol = offer.metal as 'AUXG' | 'AUXS' | 'AUXPT' | 'AUXPD';
      const durationMonths = selectedPeriod as 3 | 6 | 12;

      await stake(metalSymbol, amountNum, durationMonths, compounding, 0);

      // Generate display stake code
      const timestamp = Date.now().toString(16).toUpperCase();
      const shortCode = `STK-${timestamp.slice(-8)}`;
      setResultShortCode(shortCode);
      setResultStakeCode(`0x${timestamp}${Math.random().toString(16).slice(2, 10)}`);

    } catch (err) {
      console.error("Stake failed:", err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm">
      <div 
        className="w-full max-w-md bg-white dark:bg-slate-900 rounded-xl sm:rounded-2xl shadow-2xl overflow-hidden border border-slate-200 dark:border-slate-800"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative p-4 sm:p-6 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-3 sm:gap-4">
            <img src={offer.icon} alt={offer.metal} className="w-10 h-10 sm:w-12 sm:h-12" />
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-slate-800 dark:text-white">
                {offer.name}
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
                {t.lockEarn}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="absolute top-3 sm:top-4 right-3 sm:right-4 p-1.5 sm:p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 transition-colors"
          >
            <svg className="w-4 h-4 sm:w-5 sm:h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 space-y-4 sm:space-y-6 max-h-[60vh] overflow-y-auto">
          {/* Period Selection */}
          <div>
            <label className="text-xs sm:text-sm font-medium text-slate-700 dark:text-slate-300 mb-2 sm:mb-3 block flex items-center gap-2">
              <svg className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              {t.lockPeriod}
            </label>
            <APYVisual
              periods={offer.periods}
              selectedPeriod={selectedPeriod}
              onSelect={setSelectedPeriod}
              lang={lang}
            />
          </div>

          {/* Amount Input */}
          <div>
            <label className="text-xs sm:text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5 sm:mb-2 block flex items-center gap-2">
              <svg className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
              </svg>
              {t.amount} (gram)
            </label>
            <div className="relative">
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder={`Min. ${offer.minAmount}g`}
                disabled={isApproving || isStaking}
                className="w-full px-3 sm:px-4 py-3 sm:py-4 pr-16 sm:pr-20 rounded-lg sm:rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors disabled:opacity-50 text-base sm:text-lg font-medium"
              />
              <button
                onClick={() => {
                  setAmount(balanceNum.toString());
                }}
                disabled={isApproving || isStaking}
                className="absolute right-2 sm:right-3 top-1/2 -translate-y-1/2 px-2 sm:px-3 py-1 sm:py-1.5 rounded-lg bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/30 text-xs sm:text-sm font-medium transition-colors disabled:opacity-50"
              >
                MAX
              </button>
            </div>
            <div className="flex justify-between mt-1.5 sm:mt-2">
              <span className="text-[10px] sm:text-xs text-slate-500 flex items-center gap-1">
                <svg className="w-2.5 h-2.5 sm:w-3 sm:h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                </svg>
                {t.balance}: {balanceNum.toFixed(4)}g
              </span>
              {amountNum > 0 && amountNum < offer.minAmount && (
                <span className="text-[10px] sm:text-xs text-red-400">
                  Min. {offer.minAmount}g
                </span>
              )}
            </div>
          </div>

          {/* Compounding Toggle */}
          <div className="flex items-center justify-between p-3 sm:p-4 rounded-lg sm:rounded-xl bg-slate-100 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-purple-500/20 flex items-center justify-center">
                <svg className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
              </div>
              <div>
                <div className="text-xs sm:text-sm font-medium text-slate-700 dark:text-slate-300">{t.compounding}</div>
                <div className="text-[10px] sm:text-xs text-slate-500 dark:text-slate-400">{t.compoundingDesc}</div>
              </div>
            </div>
            <button
              onClick={() => setCompounding(!compounding)}
              className={`w-10 sm:w-12 h-5 sm:h-6 rounded-full transition-colors ${
                compounding ? "bg-purple-500" : "bg-slate-300 dark:bg-slate-600"
              }`}
            >
              <div className={`w-4 sm:w-5 h-4 sm:h-5 rounded-full bg-white shadow-md transform transition-transform ${
                compounding ? "translate-x-5 sm:translate-x-6" : "translate-x-0.5"
              }`} />
            </button>
          </div>

          {/* Earnings Calculator */}
          <EarningsCalculator
            amount={amountNum}
            apy={currentPeriod.apy}
            days={periodDays}
            metalSymbol={offer.metal}
            lang={lang}
          />

          {/* Success Message with Stake Code */}
          {isStakeSuccess && resultShortCode && (
            <div className="space-y-3 sm:space-y-4">
              <div className="rounded-lg sm:rounded-xl bg-emerald-500/20 border border-emerald-500/30 p-3 sm:p-4">
                <div className="flex items-center gap-2 sm:gap-3">
                  <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-emerald-500/30 flex items-center justify-center">
                    <svg className="w-5 h-5 sm:w-6 sm:h-6 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <div>
                    <div className="text-xs sm:text-sm font-medium text-emerald-600 dark:text-emerald-300">
                      {t.lockSuccess}
                    </div>
                    <div className="text-[10px] sm:text-xs text-emerald-500 dark:text-emerald-400/70">
                      {t.positionCreated}
                    </div>
                  </div>
                </div>
              </div>

              <StakeCodeDisplay
                stakeCode={resultStakeCode || ""}
                shortCode={resultShortCode}
                txHash={stakeHash}
                lang={lang}
              />
            </div>
          )}

          {/* Transaction Pending */}
          {isStaking && !isStakeSuccess && (
            <div className="rounded-lg sm:rounded-xl bg-blue-500/20 border border-blue-500/30 p-3 sm:p-4">
              <div className="flex items-center gap-2 sm:gap-3">
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-blue-500/30 flex items-center justify-center">
                  <svg className="w-5 h-5 sm:w-6 sm:h-6 text-blue-400 animate-spin" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                </div>
                <div>
                  <div className="text-xs sm:text-sm font-medium text-blue-600 dark:text-blue-300">
                    {t.txConfirming}
                  </div>
                  <div className="text-[10px] sm:text-xs text-blue-500 dark:text-blue-400/70">
                    {t.txPending}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Approval Success Message */}
          {isApproveSuccess && !needsApproval && !isStakeSuccess && !isStaking && (
            <div className="rounded-lg sm:rounded-xl bg-blue-500/20 border border-blue-500/30 p-3 sm:p-4">
              <div className="flex items-center gap-2 sm:gap-3">
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-blue-500/30 flex items-center justify-center">
                  <svg className="w-5 h-5 sm:w-6 sm:h-6 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <div className="text-xs sm:text-sm font-medium text-blue-600 dark:text-blue-300">
                    {t.approved}
                  </div>
                  <div className="text-[10px] sm:text-xs text-blue-500 dark:text-blue-400/70">
                    {t.canLockNow}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Info Notice */}
          {!isStakeSuccess && !isApproveSuccess && !isStaking && !isApproving && (
            <div className="rounded-lg sm:rounded-xl bg-stone-100 dark:bg-slate-800/50 border border-stone-200 dark:border-slate-700 p-3 sm:p-4">
              <div className="flex items-start gap-2 sm:gap-3">
                <svg className="w-4 h-4 sm:w-5 sm:h-5 text-slate-500 mt-0.5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="text-[10px] sm:text-xs text-slate-600 dark:text-slate-400">
                  {periodDays} {t.infoNotice}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-6 border-t border-stone-200 dark:border-slate-800 space-y-2 sm:space-y-3">
          {needsApproval && !isStakeSuccess ? (
            <button
              onClick={handleApprove}
              disabled={!amount || amountNum < offer.minAmount || isApproving || isStaking}
              className="w-full px-3 sm:px-4 py-3 sm:py-4 rounded-lg sm:rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-400 hover:to-blue-500 disabled:from-slate-700 disabled:to-slate-700 disabled:text-slate-500 disabled:cursor-not-allowed text-white font-semibold text-sm sm:text-base transition-all shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2"
            >
              {isApproving ? (
                <>
                  <svg className="animate-spin h-4 w-4 sm:h-5 sm:w-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  {t.approving}
                </>
              ) : (
                <>
                  <svg className="w-4 h-4 sm:w-5 sm:h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                  {t.approveToken}
                </>
              )}
            </button>
          ) : !isStakeSuccess ? (
            <button
              onClick={handleStake}
              disabled={!amount || amountNum < offer.minAmount || isApproving || isStaking || needsApproval}
              className="w-full px-3 sm:px-4 py-3 sm:py-4 rounded-lg sm:rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 disabled:from-slate-700 disabled:to-slate-700 disabled:text-slate-500 disabled:cursor-not-allowed text-white font-semibold text-sm sm:text-base transition-all shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2"
            >
              {isStaking ? (
                <>
                  <svg className="animate-spin h-4 w-4 sm:h-5 sm:w-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  {t.locking}
                </>
              ) : (
                <>
                  <svg className="w-4 h-4 sm:w-5 sm:h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  {t.lockEarn}
                </>
              )}
            </button>
          ) : null}

          {!isStakeSuccess && (
            <button
              onClick={onClose}
              disabled={isApproving || isStaking}
              className="w-full px-3 sm:px-4 py-2.5 sm:py-3 rounded-lg sm:rounded-xl bg-stone-200 dark:bg-slate-800 hover:bg-stone-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-medium text-sm sm:text-base transition-colors disabled:opacity-50"
            >
              {t.cancel}
            </button>
          )}

          {isStakeSuccess && (
            <button
              onClick={onClose}
              className="w-full px-3 sm:px-4 py-2.5 sm:py-3 rounded-lg sm:rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-medium text-sm sm:text-base transition-colors"
            >
              {t.done}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export { AllocationModal };
export default AllocationModal;
