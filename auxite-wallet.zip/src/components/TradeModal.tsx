"use client";

import { useState, useEffect } from "react";
import { useMetalsPrices } from "@/hooks/useMetalsPrices";

interface TradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang?: "tr" | "en";
  walletAddress?: string;
  auxmBalance?: number;
}

const metals = [
  { id: "AUXG", name: "Gold", nameTr: "Altın", icon: "/gold-favicon-32x32.png" },
  { id: "AUXS", name: "Silver", nameTr: "Gümüş", icon: "/silver-favicon-32x32.png" },
  { id: "AUXPT", name: "Platinum", nameTr: "Platin", icon: "/platinum-favicon-32x32.png" },
  { id: "AUXPD", name: "Palladium", nameTr: "Paladyum", icon: "/palladium-favicon-32x32.png" },
];

export function TradeModal({ isOpen, onClose, lang = "en", walletAddress, auxmBalance = 0 }: TradeModalProps) {
  const [mode, setMode] = useState<"buy" | "sell">("buy");
  const [selectedMetal, setSelectedMetal] = useState("AUXG");
  const [amount, setAmount] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  
  const { prices } = useMetalsPrices();
  
  const metalPrice = prices[selectedMetal] || 0;
  const amountNum = parseFloat(amount) || 0;
  
  // Calculate values
  const auxmRequired = mode === "buy" ? amountNum * metalPrice : 0;
  const auxmReceived = mode === "sell" ? amountNum * metalPrice : 0;
  
  const canTrade = mode === "buy" 
    ? auxmRequired > 0 && auxmRequired <= auxmBalance 
    : amountNum > 0;

  const handleTrade = async () => {
    if (!walletAddress || !canTrade) return;
    
    setLoading(true);
    setError(null);
    setSuccess(null);
    
    try {
      const response = await fetch("/api/trade", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          address: walletAddress,
          action: mode,
          metal: selectedMetal,
          amount: amountNum,
        }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || "Trade failed");
      }
      
      setSuccess(
        mode === "buy"
          ? lang === "tr" 
            ? `${amountNum.toFixed(2)}g ${selectedMetal} satın alındı!` 
            : `Bought ${amountNum.toFixed(2)}g ${selectedMetal}!`
          : lang === "tr"
            ? `${amountNum.toFixed(2)}g ${selectedMetal} satıldı!`
            : `Sold ${amountNum.toFixed(2)}g ${selectedMetal}!`
      );
      
      setAmount("");
      
      // Close after 2 seconds
      setTimeout(() => {
        onClose();
        setSuccess(null);
      }, 2000);
      
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-slate-900 rounded-2xl border border-slate-700 w-full max-w-md">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <h2 className="text-lg font-bold text-white">
            {lang === "tr" ? "Metal Al/Sat" : "Trade Metal"}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-800 rounded-lg transition-colors"
          >
            <svg className="w-5 h-5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          {/* Buy/Sell Toggle */}
          <div className="flex gap-2 p-1 bg-slate-800 rounded-lg">
            <button
              onClick={() => setMode("buy")}
              className={`flex-1 py-2 rounded-md text-sm font-medium transition-colors ${
                mode === "buy"
                  ? "bg-emerald-500 text-white"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              {lang === "tr" ? "Al" : "Buy"}
            </button>
            <button
              onClick={() => setMode("sell")}
              className={`flex-1 py-2 rounded-md text-sm font-medium transition-colors ${
                mode === "sell"
                  ? "bg-red-500 text-white"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              {lang === "tr" ? "Sat" : "Sell"}
            </button>
          </div>

          {/* AUXM Balance */}
          <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-400">AUXM {lang === "tr" ? "Bakiye" : "Balance"}</span>
              <span className="text-lg font-bold text-emerald-400">
                ${auxmBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>

          {/* Metal Selection */}
          <div>
            <label className="text-sm text-slate-400 mb-2 block">
              {lang === "tr" ? "Metal Seç" : "Select Metal"}
            </label>
            <div className="grid grid-cols-4 gap-2">
              {metals.map((metal) => (
                <button
                  key={metal.id}
                  onClick={() => setSelectedMetal(metal.id)}
                  className={`flex flex-col items-center gap-1 p-3 rounded-xl border transition-all ${
                    selectedMetal === metal.id
                      ? "bg-amber-500/20 border-amber-500"
                      : "bg-slate-800 border-slate-700 hover:border-slate-600"
                  }`}
                >
                  <img src={metal.icon} alt={metal.id} className="w-8 h-8" />
                  <span className="text-xs text-slate-300">{metal.id}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Price Info */}
          <div className="bg-slate-800/50 rounded-xl p-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-400">
                {selectedMetal} {lang === "tr" ? "Fiyat" : "Price"}
              </span>
              <span className="text-white font-mono">
                ${metalPrice.toFixed(2)}/g
              </span>
            </div>
          </div>

          {/* Amount Input */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm text-slate-400">
                {lang === "tr" ? "Miktar (gram)" : "Amount (grams)"}
              </label>
              {mode === "buy" && (
                <button
                  onClick={() => {
                    const maxGrams = metalPrice > 0 ? auxmBalance / metalPrice : 0;
                    setAmount(maxGrams.toFixed(2));
                  }}
                  className="text-xs text-emerald-500 hover:text-emerald-400"
                >
                  MAX
                </button>
              )}
            </div>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Calculation */}
          <div className="bg-slate-800/50 rounded-xl p-4">
            {mode === "buy" ? (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">{lang === "tr" ? "Alacağınız" : "You receive"}</span>
                  <span className="text-white font-medium">{amountNum.toFixed(2)}g {selectedMetal}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">{lang === "tr" ? "Ödeyeceğiniz" : "You pay"}</span>
                  <span className={`font-medium ${auxmRequired > auxmBalance ? "text-red-400" : "text-emerald-400"}`}>
                    ${auxmRequired.toFixed(2)} AUXM
                  </span>
                </div>
                {auxmRequired > auxmBalance && (
                  <p className="text-xs text-red-400 mt-2">
                    {lang === "tr" ? "Yetersiz AUXM bakiyesi" : "Insufficient AUXM balance"}
                  </p>
                )}
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">{lang === "tr" ? "Satacağınız" : "You sell"}</span>
                  <span className="text-white font-medium">{amountNum.toFixed(2)}g {selectedMetal}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">{lang === "tr" ? "Alacağınız" : "You receive"}</span>
                  <span className="text-emerald-400 font-medium">${auxmReceived.toFixed(2)} AUXM</span>
                </div>
              </div>
            )}
          </div>

          {/* Error/Success Messages */}
          {error && (
            <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-3 text-red-400 text-sm">
              {error}
            </div>
          )}
          {success && (
            <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-3 text-emerald-400 text-sm">
              {success}
            </div>
          )}

          {/* Trade Button */}
          <button
            onClick={handleTrade}
            disabled={!canTrade || loading}
            className={`w-full py-3 rounded-xl font-semibold transition-colors flex items-center justify-center gap-2 ${
              mode === "buy"
                ? "bg-emerald-500 hover:bg-emerald-400 disabled:bg-emerald-500/50"
                : "bg-red-500 hover:bg-red-400 disabled:bg-red-500/50"
            } text-white disabled:cursor-not-allowed`}
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                {mode === "buy" 
                  ? (lang === "tr" ? "Satın Al" : "Buy") 
                  : (lang === "tr" ? "Sat" : "Sell")}
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

export default TradeModal;
