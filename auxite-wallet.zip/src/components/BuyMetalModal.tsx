"use client";

import { useState, useEffect } from "react";

interface BuyMetalModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang?: "tr" | "en";
  defaultMetal?: MetalType;
  auxmBalance?: number;
  metalPrices?: {
    AUXG: number;
    AUXS: number;
    AUXPT: number;
    AUXPD: number;
  };
  metalBalances?: {
    AUXG: number;
    AUXS: number;
    AUXPT: number;
    AUXPD: number;
  };
}

type MetalType = "AUXG" | "AUXS" | "AUXPT" | "AUXPD";

const METALS: Record<MetalType, { 
  name: string; 
  nameTr: string; 
  icon: string; 
  color: string;
}> = {
  AUXG: { name: "Gold", nameTr: "Altın", icon: "🥇", color: "#F59E0B" },
  AUXS: { name: "Silver", nameTr: "Gümüş", icon: "🥈", color: "#94A3B8" },
  AUXPT: { name: "Platinum", nameTr: "Platin", icon: "⚪", color: "#CBD5E1" },
  AUXPD: { name: "Palladium", nameTr: "Paladyum", icon: "🔘", color: "#64748B" },
};

export function BuyMetalModal({
  isOpen,
  onClose,
  lang = "tr",
  defaultMetal = "AUXG",
  auxmBalance = 5000,
  metalPrices = { AUXG: 139.31, AUXS: 1.79, AUXPT: 54.14, AUXPD: 48.16 },
  metalBalances = { AUXG: 15.75, AUXS: 250.00, AUXPT: 5.25, AUXPD: 3.50 },
}: BuyMetalModalProps) {
  const [selectedMetal, setSelectedMetal] = useState<MetalType>(defaultMetal);
  const [amount, setAmount] = useState<string>("");
  const [inputType, setInputType] = useState<"gram" | "auxm">("gram");
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<"success" | "error" | null>(null);

  useEffect(() => {
    if (isOpen) {
      setAmount("");
      setResult(null);
      setSelectedMetal(defaultMetal);
      setInputType("gram");
    }
  }, [isOpen, defaultMetal]);

  if (!isOpen) return null;

  const metalPrice = metalPrices[selectedMetal];
  const amountNum = parseFloat(amount) || 0;

  // Hesaplamalar
  let gramAmount: number;
  let auxmAmount: number;

  if (inputType === "gram") {
    gramAmount = amountNum;
    auxmAmount = amountNum * metalPrice;
  } else {
    auxmAmount = amountNum;
    gramAmount = amountNum / metalPrice;
  }

  // Spread %0.5 (dahili - kullanıcıya gösterilmez)
  const spreadPercent = 0.5;
  const totalAuxm = auxmAmount * (1 + spreadPercent / 100);

  const canAfford = totalAuxm <= auxmBalance && amountNum > 0;
  const currentMetalBalance = metalBalances[selectedMetal];

  const handleBuy = async () => {
    if (!canAfford) return;
    setIsProcessing(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      setResult("success");
      setTimeout(() => onClose(), 2500);
    } catch {
      setResult("error");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />

      <div className="relative z-10 w-full max-w-md bg-slate-900 rounded-2xl border border-slate-700">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800">
          <div>
            <h2 className="text-base font-bold text-white">
              {lang === "tr" ? "Hızlı Al" : "Quick Buy"}
            </h2>
            <p className="text-xs text-slate-400">
              {lang === "tr" ? "AUXM ile metal satın alın" : "Buy metals with AUXM"}
            </p>
          </div>
          <button onClick={onClose} className="p-1.5 hover:bg-slate-800 rounded-lg">
            <svg className="w-5 h-5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          {/* Success State */}
          {result === "success" ? (
            <div className="text-center py-8">
              <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-emerald-500/20 flex items-center justify-center">
                <svg className="w-7 h-7 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h3 className="text-lg font-bold text-emerald-400 mb-2">
                {lang === "tr" ? "Satın Alma Başarılı!" : "Purchase Successful!"}
              </h3>
              <p className="text-slate-400">
                <span className="text-2xl mr-2">{METALS[selectedMetal].icon}</span>
                {gramAmount.toFixed(4)}g {selectedMetal}
              </p>
              <p className="text-slate-500 text-sm mt-1">
                {totalAuxm.toFixed(2)} AUXM
              </p>
            </div>
          ) : (
            <>
              {/* AUXM Balance */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-purple-500/10 border border-purple-500/30">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold">
                    ◈
                  </div>
                  <div>
                    <div className="text-xs text-purple-300">{lang === "tr" ? "AUXM Bakiyeniz" : "Your AUXM Balance"}</div>
                    <div className="font-bold text-white">{auxmBalance.toLocaleString()} AUXM</div>
                  </div>
                </div>
                <div className="text-right text-xs text-slate-400">
                  ≈ ${auxmBalance.toLocaleString()}
                </div>
              </div>

              {/* Metal Selection */}
              <div>
                <div className="text-sm text-slate-400 mb-2">
                  {lang === "tr" ? "Metal Seçin" : "Select Metal"}
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {(["AUXG", "AUXS", "AUXPT", "AUXPD"] as MetalType[]).map((metal) => {
                    const info = METALS[metal];
                    const isSelected = selectedMetal === metal;
                    const price = metalPrices[metal];
                    
                    return (
                      <button
                        key={metal}
                        onClick={() => setSelectedMetal(metal)}
                        className={`p-3 rounded-xl border transition-all flex flex-col items-center ${
                          isSelected
                            ? "border-purple-500 bg-purple-500/20"
                            : "border-slate-700 bg-slate-800/50 hover:border-slate-600"
                        }`}
                      >
                        <span className="text-2xl mb-1">{info.icon}</span>
                        <span className="text-xs font-semibold text-white">{metal}</span>
                        <span className="text-[10px] text-slate-400">${price.toFixed(2)}/g</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Current Metal Balance */}
              <div className="text-xs text-slate-500 text-center">
                {lang === "tr" ? "Mevcut" : "Current"} {selectedMetal}: {currentMetalBalance.toFixed(4)}g
              </div>

              {/* Amount Input */}
              <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700">
                {/* Input Type Toggle */}
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-xs text-slate-400">{lang === "tr" ? "Miktar türü" : "Amount type"}:</span>
                  <div className="flex bg-slate-900 rounded-lg p-0.5">
                    <button
                      onClick={() => { setInputType("gram"); setAmount(""); }}
                      className={`px-3 py-1 text-xs rounded-md transition-all ${
                        inputType === "gram"
                          ? "bg-purple-500 text-white"
                          : "text-slate-400 hover:text-white"
                      }`}
                    >
                      Gram
                    </button>
                    <button
                      onClick={() => { setInputType("auxm"); setAmount(""); }}
                      className={`px-3 py-1 text-xs rounded-md transition-all ${
                        inputType === "auxm"
                          ? "bg-purple-500 text-white"
                          : "text-slate-400 hover:text-white"
                      }`}
                    >
                      AUXM
                    </button>
                  </div>
                </div>

                {/* Input */}
                <div className="relative">
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    disabled={isProcessing}
                    className="w-full bg-slate-900 rounded-lg px-4 py-3 text-xl font-mono text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                  />
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 text-sm text-slate-400">
                    {inputType === "gram" ? "gram" : "AUXM"}
                  </div>
                </div>

                {/* Quick Amount Buttons */}
                {inputType === "auxm" && (
                  <div className="flex gap-2 mt-2">
                    {[100, 500, 1000].map((val) => (
                      <button
                        key={val}
                        onClick={() => setAmount(val.toString())}
                        className="flex-1 py-1.5 text-xs rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 transition-colors"
                      >
                        {val} AUXM
                      </button>
                    ))}
                    <button
                      onClick={() => setAmount(auxmBalance.toString())}
                      className="px-3 py-1.5 text-xs rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 transition-colors font-semibold"
                    >
                      MAX
                    </button>
                  </div>
                )}

                {inputType === "gram" && (
                  <div className="flex gap-2 mt-2">
                    {[1, 5, 10].map((val) => (
                      <button
                        key={val}
                        onClick={() => setAmount(val.toString())}
                        className="flex-1 py-1.5 text-xs rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 transition-colors"
                      >
                        {val}g
                      </button>
                    ))}
                    <button
                      onClick={() => {
                        const maxGram = auxmBalance / metalPrice / (1 + spreadPercent / 100);
                        setAmount(maxGram.toFixed(4));
                      }}
                      className="px-3 py-1.5 text-xs rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 transition-colors font-semibold"
                    >
                      MAX
                    </button>
                  </div>
                )}
              </div>

              {/* Summary */}
              {amountNum > 0 && (
                <div className="p-3 rounded-xl bg-slate-800/30 border border-slate-700 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-400">{lang === "tr" ? "Alacağınız" : "You will receive"}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{METALS[selectedMetal].icon}</span>
                      <span className="text-lg font-bold text-white">{gramAmount.toFixed(4)}g</span>
                      <span className="text-sm text-slate-400">{selectedMetal}</span>
                    </div>
                  </div>
                  
                  <div className="border-t border-slate-700 pt-2 space-y-1 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-400">{lang === "tr" ? "Fiyat" : "Price"}</span>
                      <span className="text-slate-300">${metalPrice.toFixed(2)}/gram</span>
                    </div>
                    <div className="flex justify-between font-semibold pt-1 border-t border-slate-700">
                      <span className="text-white">{lang === "tr" ? "Toplam" : "Total"}</span>
                      <span className="text-white">{totalAuxm.toFixed(2)} AUXM</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Insufficient Balance Warning */}
              {!canAfford && amountNum > 0 && (
                <div className="px-3 py-2 rounded-lg bg-red-500/10 border border-red-500/30 text-sm text-red-400">
                  ⚠️ {lang === "tr" ? "Yetersiz AUXM bakiyesi" : "Insufficient AUXM balance"}
                </div>
              )}

              {/* Buy Button */}
              <button
                onClick={handleBuy}
                disabled={isProcessing || !canAfford}
                className="w-full py-3 rounded-xl font-semibold text-white bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2"
              >
                {isProcessing ? (
                  <>
                    <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                    {lang === "tr" ? "İşleniyor..." : "Processing..."}
                  </>
                ) : (
                  <>
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                    {lang === "tr" ? "Satın Al" : "Buy Now"}
                  </>
                )}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default BuyMetalModal;
